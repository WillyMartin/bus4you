<?php

namespace Bundles\ParameterBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BundlesParameterBundle extends Bundle
{
}
