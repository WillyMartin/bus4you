<?php

namespace Bundles\CallMeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BundlesCallMeBundle extends Bundle
{
}
