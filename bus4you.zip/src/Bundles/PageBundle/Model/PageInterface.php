<?php

namespace Bundles\PageBundle\Model;

interface PageInterface
{
}

