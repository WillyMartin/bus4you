<?php

namespace Bundles\PageBundle\Repository;

use Knp\DoctrineBehaviors\ORM as ORMBehaviors;

class MenuRepository extends \Doctrine\ORM\EntityRepository
{

}
