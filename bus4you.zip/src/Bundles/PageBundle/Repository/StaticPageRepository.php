<?php

namespace Bundles\PageBundle\Repository;

class StaticPageRepository extends \Doctrine\ORM\EntityRepository
{

}
