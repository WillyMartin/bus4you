<?php

namespace Bundles\ParameterBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Bundles\ParameterBundle\Entity\Parameter;

class LoadStaticPages implements FixtureInterface
{
    public function load(ObjectManager $manager)
    {
//        $page = new Parameter();
//        
//        $manager->persist($param);
//        $manager->flush();
    }
}