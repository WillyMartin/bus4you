<?php

namespace Bundles\PageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BundlesPageBundle extends Bundle
{
}
