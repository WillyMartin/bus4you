<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // homepage
        if ('' === $trimmedPathinfo) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/admin')) {
            // sonata_admin_redirect
            if ('/admin' === $trimmedPathinfo) {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'sonata_admin_redirect');
                }

                return array (  '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController::redirectAction',  'route' => 'sonata_admin_dashboard',  'permanent' => 'true',  '_route' => 'sonata_admin_redirect',);
            }

            // sonata_admin_dashboard
            if ('/admin/dashboard' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::dashboardAction',  '_route' => 'sonata_admin_dashboard',);
            }

            if (0 === strpos($pathinfo, '/admin/core')) {
                if (0 === strpos($pathinfo, '/admin/core/get-')) {
                    // sonata_admin_retrieve_form_element
                    if ('/admin/core/get-form-field-element' === $pathinfo) {
                        return array (  '_controller' => 'sonata.admin.controller.admin:retrieveFormFieldElementAction',  '_route' => 'sonata_admin_retrieve_form_element',);
                    }

                    // sonata_admin_short_object_information
                    if (0 === strpos($pathinfo, '/admin/core/get-short-object-description') && preg_match('#^/admin/core/get\\-short\\-object\\-description(?:\\.(?P<_format>html|json))?$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_admin_short_object_information')), array (  '_controller' => 'sonata.admin.controller.admin:getShortObjectDescriptionAction',  '_format' => 'html',));
                    }

                    // sonata_admin_retrieve_autocomplete_items
                    if ('/admin/core/get-autocomplete-items' === $pathinfo) {
                        return array (  '_controller' => 'sonata.admin.controller.admin:retrieveAutocompleteItemsAction',  '_route' => 'sonata_admin_retrieve_autocomplete_items',);
                    }

                }

                // sonata_admin_append_form_element
                if ('/admin/core/append-form-field-element' === $pathinfo) {
                    return array (  '_controller' => 'sonata.admin.controller.admin:appendFormFieldElementAction',  '_route' => 'sonata_admin_append_form_element',);
                }

                // sonata_admin_set_object_field_value
                if ('/admin/core/set-object-field-value' === $pathinfo) {
                    return array (  '_controller' => 'sonata.admin.controller.admin:setObjectFieldValueAction',  '_route' => 'sonata_admin_set_object_field_value',);
                }

            }

            // sonata_admin_search
            if ('/admin/search' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::searchAction',  '_route' => 'sonata_admin_search',);
            }

            if (0 === strpos($pathinfo, '/admin/bundles/page')) {
                if (0 === strpos($pathinfo, '/admin/bundles/page/staticpage')) {
                    // admin_bundles_page_staticpage_list
                    if ('/admin/bundles/page/staticpage/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_list',  '_route' => 'admin_bundles_page_staticpage_list',);
                    }

                    // admin_bundles_page_staticpage_create
                    if ('/admin/bundles/page/staticpage/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_create',  '_route' => 'admin_bundles_page_staticpage_create',);
                    }

                    // admin_bundles_page_staticpage_batch
                    if ('/admin/bundles/page/staticpage/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_batch',  '_route' => 'admin_bundles_page_staticpage_batch',);
                    }

                    // admin_bundles_page_staticpage_edit
                    if (preg_match('#^/admin/bundles/page/staticpage/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_staticpage_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_edit',));
                    }

                    // admin_bundles_page_staticpage_delete
                    if (preg_match('#^/admin/bundles/page/staticpage/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_staticpage_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_delete',));
                    }

                    // admin_bundles_page_staticpage_show
                    if (preg_match('#^/admin/bundles/page/staticpage/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_staticpage_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_show',));
                    }

                    // admin_bundles_page_staticpage_export
                    if ('/admin/bundles/page/staticpage/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.static_page',  '_sonata_name' => 'admin_bundles_page_staticpage_export',  '_route' => 'admin_bundles_page_staticpage_export',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/admin/bundles/page/page')) {
                    // admin_bundles_page_page_list
                    if ('/admin/bundles/page/page/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_list',  '_route' => 'admin_bundles_page_page_list',);
                    }

                    // admin_bundles_page_page_create
                    if ('/admin/bundles/page/page/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_create',  '_route' => 'admin_bundles_page_page_create',);
                    }

                    // admin_bundles_page_page_batch
                    if ('/admin/bundles/page/page/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_batch',  '_route' => 'admin_bundles_page_page_batch',);
                    }

                    // admin_bundles_page_page_edit
                    if (preg_match('#^/admin/bundles/page/page/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_page_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_edit',));
                    }

                    // admin_bundles_page_page_delete
                    if (preg_match('#^/admin/bundles/page/page/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_page_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_delete',));
                    }

                    // admin_bundles_page_page_show
                    if (preg_match('#^/admin/bundles/page/page/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_page_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_show',));
                    }

                    // admin_bundles_page_page_export
                    if ('/admin/bundles/page/page/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.page',  '_sonata_name' => 'admin_bundles_page_page_export',  '_route' => 'admin_bundles_page_page_export',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/admin/bundles/page/article')) {
                    // admin_bundles_page_article_list
                    if ('/admin/bundles/page/article/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_list',  '_route' => 'admin_bundles_page_article_list',);
                    }

                    // admin_bundles_page_article_create
                    if ('/admin/bundles/page/article/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_create',  '_route' => 'admin_bundles_page_article_create',);
                    }

                    // admin_bundles_page_article_batch
                    if ('/admin/bundles/page/article/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_batch',  '_route' => 'admin_bundles_page_article_batch',);
                    }

                    // admin_bundles_page_article_edit
                    if (preg_match('#^/admin/bundles/page/article/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_article_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_edit',));
                    }

                    // admin_bundles_page_article_delete
                    if (preg_match('#^/admin/bundles/page/article/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_article_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_delete',));
                    }

                    // admin_bundles_page_article_show
                    if (preg_match('#^/admin/bundles/page/article/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_article_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_show',));
                    }

                    // admin_bundles_page_article_export
                    if ('/admin/bundles/page/article/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.article',  '_sonata_name' => 'admin_bundles_page_article_export',  '_route' => 'admin_bundles_page_article_export',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/admin/bundles/page/menu')) {
                    // admin_bundles_page_menu_list
                    if ('/admin/bundles/page/menu/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_list',  '_route' => 'admin_bundles_page_menu_list',);
                    }

                    // admin_bundles_page_menu_create
                    if ('/admin/bundles/page/menu/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_create',  '_route' => 'admin_bundles_page_menu_create',);
                    }

                    // admin_bundles_page_menu_batch
                    if ('/admin/bundles/page/menu/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_batch',  '_route' => 'admin_bundles_page_menu_batch',);
                    }

                    // admin_bundles_page_menu_edit
                    if (preg_match('#^/admin/bundles/page/menu/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_menu_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_edit',));
                    }

                    // admin_bundles_page_menu_delete
                    if (preg_match('#^/admin/bundles/page/menu/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_menu_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_delete',));
                    }

                    // admin_bundles_page_menu_show
                    if (preg_match('#^/admin/bundles/page/menu/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_page_menu_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_show',));
                    }

                    // admin_bundles_page_menu_export
                    if ('/admin/bundles/page/menu/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.menu',  '_sonata_name' => 'admin_bundles_page_menu_export',  '_route' => 'admin_bundles_page_menu_export',);
                    }

                }

            }

            elseif (0 === strpos($pathinfo, '/admin/bundles/callme')) {
                if (0 === strpos($pathinfo, '/admin/bundles/callme/callme')) {
                    // admin_bundles_callme_callme_list
                    if ('/admin/bundles/callme/callme/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_list',  '_route' => 'admin_bundles_callme_callme_list',);
                    }

                    // admin_bundles_callme_callme_create
                    if ('/admin/bundles/callme/callme/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_create',  '_route' => 'admin_bundles_callme_callme_create',);
                    }

                    // admin_bundles_callme_callme_batch
                    if ('/admin/bundles/callme/callme/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_batch',  '_route' => 'admin_bundles_callme_callme_batch',);
                    }

                    // admin_bundles_callme_callme_edit
                    if (preg_match('#^/admin/bundles/callme/callme/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_callme_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_edit',));
                    }

                    // admin_bundles_callme_callme_delete
                    if (preg_match('#^/admin/bundles/callme/callme/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_callme_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_delete',));
                    }

                    // admin_bundles_callme_callme_show
                    if (preg_match('#^/admin/bundles/callme/callme/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_callme_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_show',));
                    }

                    // admin_bundles_callme_callme_export
                    if ('/admin/bundles/callme/callme/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.store.call_me',  '_sonata_name' => 'admin_bundles_callme_callme_export',  '_route' => 'admin_bundles_callme_callme_export',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/admin/bundles/callme/trip')) {
                    // admin_bundles_callme_trip_list
                    if ('/admin/bundles/callme/trip/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_list',  '_route' => 'admin_bundles_callme_trip_list',);
                    }

                    // admin_bundles_callme_trip_create
                    if ('/admin/bundles/callme/trip/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_create',  '_route' => 'admin_bundles_callme_trip_create',);
                    }

                    // admin_bundles_callme_trip_batch
                    if ('/admin/bundles/callme/trip/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_batch',  '_route' => 'admin_bundles_callme_trip_batch',);
                    }

                    // admin_bundles_callme_trip_edit
                    if (preg_match('#^/admin/bundles/callme/trip/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_trip_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_edit',));
                    }

                    // admin_bundles_callme_trip_delete
                    if (preg_match('#^/admin/bundles/callme/trip/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_trip_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_delete',));
                    }

                    // admin_bundles_callme_trip_show
                    if (preg_match('#^/admin/bundles/callme/trip/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_trip_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_show',));
                    }

                    // admin_bundles_callme_trip_export
                    if ('/admin/bundles/callme/trip/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.store.trip',  '_sonata_name' => 'admin_bundles_callme_trip_export',  '_route' => 'admin_bundles_callme_trip_export',);
                    }

                }

                elseif (0 === strpos($pathinfo, '/admin/bundles/callme/subject')) {
                    // admin_bundles_callme_subject_list
                    if ('/admin/bundles/callme/subject/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_list',  '_route' => 'admin_bundles_callme_subject_list',);
                    }

                    // admin_bundles_callme_subject_create
                    if ('/admin/bundles/callme/subject/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_create',  '_route' => 'admin_bundles_callme_subject_create',);
                    }

                    // admin_bundles_callme_subject_batch
                    if ('/admin/bundles/callme/subject/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_batch',  '_route' => 'admin_bundles_callme_subject_batch',);
                    }

                    // admin_bundles_callme_subject_edit
                    if (preg_match('#^/admin/bundles/callme/subject/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_subject_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_edit',));
                    }

                    // admin_bundles_callme_subject_delete
                    if (preg_match('#^/admin/bundles/callme/subject/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_subject_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_delete',));
                    }

                    // admin_bundles_callme_subject_show
                    if (preg_match('#^/admin/bundles/callme/subject/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_bundles_callme_subject_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_show',));
                    }

                    // admin_bundles_callme_subject_export
                    if ('/admin/bundles/callme/subject/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.admin.call_me.subject',  '_sonata_name' => 'admin_bundles_callme_subject_export',  '_route' => 'admin_bundles_callme_subject_export',);
                    }

                }

            }

        }

        elseif (0 === strpos($pathinfo, '/login')) {
            // fos_user_security_login
            if ('/login' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_security_login;
                }

                return array (  '_controller' => 'Bundles\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
            }
            not_fos_user_security_login:

            // fos_user_security_check
            if ('/login_check' === $pathinfo) {
                if ('POST' !== $canonicalMethod) {
                    $allow[] = 'POST';
                    goto not_fos_user_security_check;
                }

                return array (  '_controller' => 'Bundles\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
            }
            not_fos_user_security_check:

        }

        // fos_user_security_logout
        if ('/logout' === $pathinfo) {
            if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                $allow = array_merge($allow, array('GET', 'POST'));
                goto not_fos_user_security_logout;
            }

            return array (  '_controller' => 'Bundles\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
        }
        not_fos_user_security_logout:

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if ('/profile' === $trimmedPathinfo) {
                if ('GET' !== $canonicalMethod) {
                    $allow[] = 'GET';
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ('/profile/edit' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

            // fos_user_change_password
            if ('/profile/change-password' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_change_password;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
            }
            not_fos_user_change_password:

        }

        elseif (0 === strpos($pathinfo, '/register')) {
            // fos_user_registration_register
            if ('/register' === $trimmedPathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_registration_register;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
            }
            not_fos_user_registration_register:

            // fos_user_registration_check_email
            if ('/register/check-email' === $pathinfo) {
                if ('GET' !== $canonicalMethod) {
                    $allow[] = 'GET';
                    goto not_fos_user_registration_check_email;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
            }
            not_fos_user_registration_check_email:

            if (0 === strpos($pathinfo, '/register/confirm')) {
                // fos_user_registration_confirm
                if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if ('GET' !== $canonicalMethod) {
                        $allow[] = 'GET';
                        goto not_fos_user_registration_confirm;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                }
                not_fos_user_registration_confirm:

                // fos_user_registration_confirmed
                if ('/register/confirmed' === $pathinfo) {
                    if ('GET' !== $canonicalMethod) {
                        $allow[] = 'GET';
                        goto not_fos_user_registration_confirmed;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                }
                not_fos_user_registration_confirmed:

            }

        }

        elseif (0 === strpos($pathinfo, '/resetting')) {
            // fos_user_resetting_request
            if ('/resetting/request' === $pathinfo) {
                if ('GET' !== $canonicalMethod) {
                    $allow[] = 'GET';
                    goto not_fos_user_resetting_request;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
            }
            not_fos_user_resetting_request:

            // fos_user_resetting_reset
            if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_resetting_reset;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
            }
            not_fos_user_resetting_reset:

            // fos_user_resetting_send_email
            if ('/resetting/send-email' === $pathinfo) {
                if ('POST' !== $canonicalMethod) {
                    $allow[] = 'POST';
                    goto not_fos_user_resetting_send_email;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
            }
            not_fos_user_resetting_send_email:

            // fos_user_resetting_check_email
            if ('/resetting/check-email' === $pathinfo) {
                if ('GET' !== $canonicalMethod) {
                    $allow[] = 'GET';
                    goto not_fos_user_resetting_check_email;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
            }
            not_fos_user_resetting_check_email:

        }

        // bundles.page.static_page
        if (preg_match('#^/(?P<slug>[^/\\.]++)\\.html$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'bundles.page.static_page')), array (  '_controller' => 'Bundles\\PageBundle\\Controller\\StaticPageController::staticPageAction',));
        }

        // bundles_call_me_feedback_reciver
        if ('/feedback-reciver' === $pathinfo) {
            return array (  '_controller' => 'Bundles\\CallMeBundle\\Controller\\CallMeController::indexAction',  '_route' => 'bundles_call_me_feedback_reciver',);
        }

        // bundles_call_me_letter_reciver
        if ('/feedback-letter-reciver' === $pathinfo) {
            return array (  '_controller' => 'Bundles\\CallMeBundle\\Controller\\LetterController::indexAction',  '_route' => 'bundles_call_me_letter_reciver',);
        }

        // bundles_call_me_trip_reciver
        if ('/trip' === $pathinfo) {
            return array (  '_controller' => 'Bundles\\CallMeBundle\\Controller\\TripController::indexAction',  '_route' => 'bundles_call_me_trip_reciver',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
