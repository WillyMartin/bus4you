<?php

/* @SonataBlock/Profiler/icon.svg */
class __TwigTemplate_bdbd3999a3357082f7969d38300710d3c7235f853239f915c6fd10363a98c591 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_283c56c6fd33d6742a7d0fd7db87992cb1c9fe11eeb102d5774f29673a00703b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_283c56c6fd33d6742a7d0fd7db87992cb1c9fe11eeb102d5774f29673a00703b->enter($__internal_283c56c6fd33d6742a7d0fd7db87992cb1c9fe11eeb102d5774f29673a00703b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SonataBlock/Profiler/icon.svg"));

        $__internal_f642693082c96e6b63203f00a840ae1136617f671df169bcf0fdadd830d7a6f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f642693082c96e6b63203f00a840ae1136617f671df169bcf0fdadd830d7a6f9->enter($__internal_f642693082c96e6b63203f00a840ae1136617f671df169bcf0fdadd830d7a6f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SonataBlock/Profiler/icon.svg"));

        // line 1
        echo "<svg height=\"24\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\">
    <path fill=\"#AAAAAA\" d=\"M832 1024v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm0-768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm896 768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm0-768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90z\"/>
</svg>
";
        
        $__internal_283c56c6fd33d6742a7d0fd7db87992cb1c9fe11eeb102d5774f29673a00703b->leave($__internal_283c56c6fd33d6742a7d0fd7db87992cb1c9fe11eeb102d5774f29673a00703b_prof);

        
        $__internal_f642693082c96e6b63203f00a840ae1136617f671df169bcf0fdadd830d7a6f9->leave($__internal_f642693082c96e6b63203f00a840ae1136617f671df169bcf0fdadd830d7a6f9_prof);

    }

    public function getTemplateName()
    {
        return "@SonataBlock/Profiler/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg height=\"24\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\">
    <path fill=\"#AAAAAA\" d=\"M832 1024v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm0-768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm896 768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90zm0-768v384q0 52-38 90t-90 38h-512q-52 0-90-38t-38-90v-384q0-52 38-90t90-38h512q52 0 90 38t38 90z\"/>
</svg>
", "@SonataBlock/Profiler/icon.svg", "/var/www/bus4you/vendor/sonata-project/block-bundle/Resources/views/Profiler/icon.svg");
    }
}
