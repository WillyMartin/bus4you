<?php

/* SonataAdminBundle:CRUD:delete.html.twig */
class __TwigTemplate_75fa1c36ab184471e939f40d9f9fa7bca949f414ec8705ed11d8808ff92bcb42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'actions' => array($this, 'block_actions'),
            'tab_menu' => array($this, 'block_tab_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate((isset($context["base_template"]) || array_key_exists("base_template", $context) ? $context["base_template"] : (function () { throw new Twig_Error_Runtime('Variable "base_template" does not exist.', 12, $this->getSourceContext()); })()), "SonataAdminBundle:CRUD:delete.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f9b093146ec894b82e14bbc1d294b1cee60184da572c542d586cd7966fede99 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f9b093146ec894b82e14bbc1d294b1cee60184da572c542d586cd7966fede99->enter($__internal_9f9b093146ec894b82e14bbc1d294b1cee60184da572c542d586cd7966fede99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:delete.html.twig"));

        $__internal_791b50ce7aa8e0c0085cb71e62758cc02112dd9a7c8b260ab40177aa40d98989 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_791b50ce7aa8e0c0085cb71e62758cc02112dd9a7c8b260ab40177aa40d98989->enter($__internal_791b50ce7aa8e0c0085cb71e62758cc02112dd9a7c8b260ab40177aa40d98989_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:delete.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f9b093146ec894b82e14bbc1d294b1cee60184da572c542d586cd7966fede99->leave($__internal_9f9b093146ec894b82e14bbc1d294b1cee60184da572c542d586cd7966fede99_prof);

        
        $__internal_791b50ce7aa8e0c0085cb71e62758cc02112dd9a7c8b260ab40177aa40d98989->leave($__internal_791b50ce7aa8e0c0085cb71e62758cc02112dd9a7c8b260ab40177aa40d98989_prof);

    }

    // line 14
    public function block_actions($context, array $blocks = array())
    {
        $__internal_67e2775f91fead8e81e5a5a1b3b6fa29aaaae5f7484e332cc12955ac877e7098 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_67e2775f91fead8e81e5a5a1b3b6fa29aaaae5f7484e332cc12955ac877e7098->enter($__internal_67e2775f91fead8e81e5a5a1b3b6fa29aaaae5f7484e332cc12955ac877e7098_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        $__internal_376656666bc8cea19dbf60974a2ca549bd7b49f89f556b6b40ca54d6455d4e88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_376656666bc8cea19dbf60974a2ca549bd7b49f89f556b6b40ca54d6455d4e88->enter($__internal_376656666bc8cea19dbf60974a2ca549bd7b49f89f556b6b40ca54d6455d4e88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        // line 15
        $this->loadTemplate("SonataAdminBundle:CRUD:action_buttons.html.twig", "SonataAdminBundle:CRUD:delete.html.twig", 15)->display($context);
        
        $__internal_376656666bc8cea19dbf60974a2ca549bd7b49f89f556b6b40ca54d6455d4e88->leave($__internal_376656666bc8cea19dbf60974a2ca549bd7b49f89f556b6b40ca54d6455d4e88_prof);

        
        $__internal_67e2775f91fead8e81e5a5a1b3b6fa29aaaae5f7484e332cc12955ac877e7098->leave($__internal_67e2775f91fead8e81e5a5a1b3b6fa29aaaae5f7484e332cc12955ac877e7098_prof);

    }

    // line 18
    public function block_tab_menu($context, array $blocks = array())
    {
        $__internal_8c9f2f5423b70dcd5f480c4d11ca5a10f2e6cb01e8c1f24ce2a15982c1fbb5c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c9f2f5423b70dcd5f480c4d11ca5a10f2e6cb01e8c1f24ce2a15982c1fbb5c4->enter($__internal_8c9f2f5423b70dcd5f480c4d11ca5a10f2e6cb01e8c1f24ce2a15982c1fbb5c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        $__internal_9a51613caa2110292eaf59fd1e1379da8e6a3efe48c4f2e36fefab61b9fd92bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a51613caa2110292eaf59fd1e1379da8e6a3efe48c4f2e36fefab61b9fd92bf->enter($__internal_9a51613caa2110292eaf59fd1e1379da8e6a3efe48c4f2e36fefab61b9fd92bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        echo $this->env->getExtension('Knp\Menu\Twig\MenuExtension')->render(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 18, $this->getSourceContext()); })()), "sidemenu", array(0 => (isset($context["action"]) || array_key_exists("action", $context) ? $context["action"] : (function () { throw new Twig_Error_Runtime('Variable "action" does not exist.', 18, $this->getSourceContext()); })())), "method"), array("currentClass" => "active", "template" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["sonata_admin"]) || array_key_exists("sonata_admin", $context) ? $context["sonata_admin"] : (function () { throw new Twig_Error_Runtime('Variable "sonata_admin" does not exist.', 18, $this->getSourceContext()); })()), "adminPool", array()), "getTemplate", array(0 => "tab_menu_template"), "method")), "twig");
        
        $__internal_9a51613caa2110292eaf59fd1e1379da8e6a3efe48c4f2e36fefab61b9fd92bf->leave($__internal_9a51613caa2110292eaf59fd1e1379da8e6a3efe48c4f2e36fefab61b9fd92bf_prof);

        
        $__internal_8c9f2f5423b70dcd5f480c4d11ca5a10f2e6cb01e8c1f24ce2a15982c1fbb5c4->leave($__internal_8c9f2f5423b70dcd5f480c4d11ca5a10f2e6cb01e8c1f24ce2a15982c1fbb5c4_prof);

    }

    // line 20
    public function block_content($context, array $blocks = array())
    {
        $__internal_d4c03d486b627b8b5f2b28625250e0ae401d1d1ab6ac12f186bcc9fa131dffa7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4c03d486b627b8b5f2b28625250e0ae401d1d1ab6ac12f186bcc9fa131dffa7->enter($__internal_d4c03d486b627b8b5f2b28625250e0ae401d1d1ab6ac12f186bcc9fa131dffa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_129d1c95003b5d0886d1b45758434b7e72640d168a4efb81654c9b202114f48f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_129d1c95003b5d0886d1b45758434b7e72640d168a4efb81654c9b202114f48f->enter($__internal_129d1c95003b5d0886d1b45758434b7e72640d168a4efb81654c9b202114f48f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 21
        echo "    <div class=\"sonata-ba-delete\">

        <div class=\"box box-danger\">
            <div class=\"box-header\">
                <h3 class=\"box-title\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_delete", array(), "SonataAdminBundle"), "html", null, true);
        echo "</h3>
            </div>
            <div class=\"box-body\">
                ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("message_delete_confirmation", array("%object%" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 28, $this->getSourceContext()); })()), "toString", array(0 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 28, $this->getSourceContext()); })())), "method")), "SonataAdminBundle"), "html", null, true);
        echo "
            </div>
            <div class=\"box-footer clearfix\">
                <form method=\"POST\" action=\"";
        // line 31
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 31, $this->getSourceContext()); })()), "generateObjectUrl", array(0 => "delete", 1 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 31, $this->getSourceContext()); })())), "method"), "html", null, true);
        echo "\">
                    <input type=\"hidden\" name=\"_method\" value=\"DELETE\">
                    <input type=\"hidden\" name=\"_sonata_csrf_token\" value=\"";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) || array_key_exists("csrf_token", $context) ? $context["csrf_token"] : (function () { throw new Twig_Error_Runtime('Variable "csrf_token" does not exist.', 33, $this->getSourceContext()); })()), "html", null, true);
        echo "\">

                    <button type=\"submit\" class=\"btn btn-danger\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> ";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("btn_delete", array(), "SonataAdminBundle"), "html", null, true);
        echo "</button>
                    ";
        // line 36
        if ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 36, $this->getSourceContext()); })()), "hasRoute", array(0 => "edit"), "method") && twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 36, $this->getSourceContext()); })()), "hasAccess", array(0 => "edit", 1 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 36, $this->getSourceContext()); })())), "method"))) {
            // line 37
            echo "                        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("delete_or", array(), "SonataAdminBundle"), "html", null, true);
            echo "

                        <a class=\"btn btn-success\" href=\"";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 39, $this->getSourceContext()); })()), "generateObjectUrl", array(0 => "edit", 1 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 39, $this->getSourceContext()); })())), "method"), "html", null, true);
            echo "\">
                            <i class=\"fa fa-pencil\" aria-hidden=\"true\"></i>
                            ";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("link_action_edit", array(), "SonataAdminBundle"), "html", null, true);
            echo "</a>
                    ";
        }
        // line 43
        echo "                </form>
            </div>
        </div>
    </div>
";
        
        $__internal_129d1c95003b5d0886d1b45758434b7e72640d168a4efb81654c9b202114f48f->leave($__internal_129d1c95003b5d0886d1b45758434b7e72640d168a4efb81654c9b202114f48f_prof);

        
        $__internal_d4c03d486b627b8b5f2b28625250e0ae401d1d1ab6ac12f186bcc9fa131dffa7->leave($__internal_d4c03d486b627b8b5f2b28625250e0ae401d1d1ab6ac12f186bcc9fa131dffa7_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 43,  132 => 41,  127 => 39,  121 => 37,  119 => 36,  115 => 35,  110 => 33,  105 => 31,  99 => 28,  93 => 25,  87 => 21,  78 => 20,  60 => 18,  50 => 15,  41 => 14,  20 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{%- block actions -%}
    {% include 'SonataAdminBundle:CRUD:action_buttons.html.twig' %}
{%- endblock -%}

{% block tab_menu %}{{ knp_menu_render(admin.sidemenu(action), {'currentClass' : 'active', 'template': sonata_admin.adminPool.getTemplate('tab_menu_template')}, 'twig') }}{% endblock %}

{% block content %}
    <div class=\"sonata-ba-delete\">

        <div class=\"box box-danger\">
            <div class=\"box-header\">
                <h3 class=\"box-title\">{{ 'title_delete'|trans({}, 'SonataAdminBundle') }}</h3>
            </div>
            <div class=\"box-body\">
                {{ 'message_delete_confirmation'|trans({'%object%': admin.toString(object)}, 'SonataAdminBundle') }}
            </div>
            <div class=\"box-footer clearfix\">
                <form method=\"POST\" action=\"{{ admin.generateObjectUrl('delete', object) }}\">
                    <input type=\"hidden\" name=\"_method\" value=\"DELETE\">
                    <input type=\"hidden\" name=\"_sonata_csrf_token\" value=\"{{ csrf_token }}\">

                    <button type=\"submit\" class=\"btn btn-danger\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> {{ 'btn_delete'|trans({}, 'SonataAdminBundle') }}</button>
                    {% if admin.hasRoute('edit') and admin.hasAccess('edit', object) %}
                        {{ 'delete_or'|trans({}, 'SonataAdminBundle') }}

                        <a class=\"btn btn-success\" href=\"{{ admin.generateObjectUrl('edit', object) }}\">
                            <i class=\"fa fa-pencil\" aria-hidden=\"true\"></i>
                            {{ 'link_action_edit'|trans({}, 'SonataAdminBundle') }}</a>
                    {% endif %}
                </form>
            </div>
        </div>
    </div>
{% endblock %}
", "SonataAdminBundle:CRUD:delete.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/delete.html.twig");
    }
}
