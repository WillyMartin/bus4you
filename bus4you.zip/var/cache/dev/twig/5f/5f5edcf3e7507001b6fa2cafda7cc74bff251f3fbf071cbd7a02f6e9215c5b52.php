<?php

/* @Twig/Exception/error403.html.twig */
class __TwigTemplate_348acacedbaf798dc7daa93a3b593fd49009610cd255b17d506ea4b29e2938f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@Twig/Exception/error403.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ebaa1a2757fa65c2eaca39969a4e6e033693e04ae27d7949a24e69d6461bc06 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ebaa1a2757fa65c2eaca39969a4e6e033693e04ae27d7949a24e69d6461bc06->enter($__internal_4ebaa1a2757fa65c2eaca39969a4e6e033693e04ae27d7949a24e69d6461bc06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error403.html.twig"));

        $__internal_7113fde239b8fdaabbab1be006a0bad0cbcba2026eedcb3f749d8195ae296d5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7113fde239b8fdaabbab1be006a0bad0cbcba2026eedcb3f749d8195ae296d5c->enter($__internal_7113fde239b8fdaabbab1be006a0bad0cbcba2026eedcb3f749d8195ae296d5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ebaa1a2757fa65c2eaca39969a4e6e033693e04ae27d7949a24e69d6461bc06->leave($__internal_4ebaa1a2757fa65c2eaca39969a4e6e033693e04ae27d7949a24e69d6461bc06_prof);

        
        $__internal_7113fde239b8fdaabbab1be006a0bad0cbcba2026eedcb3f749d8195ae296d5c->leave($__internal_7113fde239b8fdaabbab1be006a0bad0cbcba2026eedcb3f749d8195ae296d5c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a0cc32f9121d840873399b95f7fb3b9e15d079d7a0a622af6c73935c633a03a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0cc32f9121d840873399b95f7fb3b9e15d079d7a0a622af6c73935c633a03a7->enter($__internal_a0cc32f9121d840873399b95f7fb3b9e15d079d7a0a622af6c73935c633a03a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8fb519074b70a4c5759aa8c2cedeb33a3ab34bf6cdb8f508e8d82a4f8d98bb33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fb519074b70a4c5759aa8c2cedeb33a3ab34bf6cdb8f508e8d82a4f8d98bb33->enter($__internal_8fb519074b70a4c5759aa8c2cedeb33a3ab34bf6cdb8f508e8d82a4f8d98bb33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Page not found - 403 error</h1>

    ";
        // line 6
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 7
            echo "        ";
            // line 8
            echo "    ";
        }
        // line 9
        echo "
    <p>
        The requested page couldn't be located. Checkout for any URL
        misspelling or <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">return to the homepage</a>.
    </p>
";
        
        $__internal_8fb519074b70a4c5759aa8c2cedeb33a3ab34bf6cdb8f508e8d82a4f8d98bb33->leave($__internal_8fb519074b70a4c5759aa8c2cedeb33a3ab34bf6cdb8f508e8d82a4f8d98bb33_prof);

        
        $__internal_a0cc32f9121d840873399b95f7fb3b9e15d079d7a0a622af6c73935c633a03a7->leave($__internal_a0cc32f9121d840873399b95f7fb3b9e15d079d7a0a622af6c73935c633a03a7_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 12,  60 => 9,  57 => 8,  55 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Page not found - 403 error</h1>

    {% if is_granted('IS_AUTHENTICATED_FULLY') %}
        {# ... #}
    {% endif %}

    <p>
        The requested page couldn't be located. Checkout for any URL
        misspelling or <a href=\"{{ path('homepage') }}\">return to the homepage</a>.
    </p>
{% endblock %}", "@Twig/Exception/error403.html.twig", "/var/www/bus4you/app/Resources/TwigBundle/views/Exception/error403.html.twig");
    }
}
