<?php

/* SonataAdminBundle:CRUD:list_string.html.twig */
class __TwigTemplate_e31621da472de31be5c2b145c0229a43dc6c9f97f4a02535837ed78074d51746 extends Twig_Template
{
    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 12, $this->getSourceContext()); })()), "getTemplate", array(0 => "base_list_field"), "method"), "SonataAdminBundle:CRUD:list_string.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73de78c044159007b1534cf155020f5e75e2db3d8acf7047514e291e93dbdf59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73de78c044159007b1534cf155020f5e75e2db3d8acf7047514e291e93dbdf59->enter($__internal_73de78c044159007b1534cf155020f5e75e2db3d8acf7047514e291e93dbdf59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_string.html.twig"));

        $__internal_43ded1d93478a00681afd44e7cdd4163c5033974dce2f020dfbd342dd3e8f98a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43ded1d93478a00681afd44e7cdd4163c5033974dce2f020dfbd342dd3e8f98a->enter($__internal_43ded1d93478a00681afd44e7cdd4163c5033974dce2f020dfbd342dd3e8f98a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_string.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_73de78c044159007b1534cf155020f5e75e2db3d8acf7047514e291e93dbdf59->leave($__internal_73de78c044159007b1534cf155020f5e75e2db3d8acf7047514e291e93dbdf59_prof);

        
        $__internal_43ded1d93478a00681afd44e7cdd4163c5033974dce2f020dfbd342dd3e8f98a->leave($__internal_43ded1d93478a00681afd44e7cdd4163c5033974dce2f020dfbd342dd3e8f98a_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:list_string.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  9 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends admin.getTemplate('base_list_field') %}
", "SonataAdminBundle:CRUD:list_string.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/list_string.html.twig");
    }
}
