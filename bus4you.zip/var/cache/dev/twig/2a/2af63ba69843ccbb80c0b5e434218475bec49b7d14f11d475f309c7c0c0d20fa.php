<?php

/* @Twig/Exception/error404.html.twig */
class __TwigTemplate_08ed87eceb26181d3c4b111d773b010d7bb1056aab24adfee1d8784f6a2c90f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@Twig/Exception/error404.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_012acc5fef747b1573a70c574e94cfd8e785984131bf2d7b37c94adb28e00d66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_012acc5fef747b1573a70c574e94cfd8e785984131bf2d7b37c94adb28e00d66->enter($__internal_012acc5fef747b1573a70c574e94cfd8e785984131bf2d7b37c94adb28e00d66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error404.html.twig"));

        $__internal_c2d28a47eb55d4732291d748c758850bb1a1bfa91c96c668cf81073aaf5d3495 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2d28a47eb55d4732291d748c758850bb1a1bfa91c96c668cf81073aaf5d3495->enter($__internal_c2d28a47eb55d4732291d748c758850bb1a1bfa91c96c668cf81073aaf5d3495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_012acc5fef747b1573a70c574e94cfd8e785984131bf2d7b37c94adb28e00d66->leave($__internal_012acc5fef747b1573a70c574e94cfd8e785984131bf2d7b37c94adb28e00d66_prof);

        
        $__internal_c2d28a47eb55d4732291d748c758850bb1a1bfa91c96c668cf81073aaf5d3495->leave($__internal_c2d28a47eb55d4732291d748c758850bb1a1bfa91c96c668cf81073aaf5d3495_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e712b0230889894b2c00d21fe6e2b308434481643e4a0c063c3e03a52db15194 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e712b0230889894b2c00d21fe6e2b308434481643e4a0c063c3e03a52db15194->enter($__internal_e712b0230889894b2c00d21fe6e2b308434481643e4a0c063c3e03a52db15194_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7e887013ebad1b28a31d9188d58cd21939870087a07708e6e4d4bb9b0d541e10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e887013ebad1b28a31d9188d58cd21939870087a07708e6e4d4bb9b0d541e10->enter($__internal_7e887013ebad1b28a31d9188d58cd21939870087a07708e6e4d4bb9b0d541e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Page not found - 404 error</h1>

    ";
        // line 6
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 7
            echo "        ";
            // line 8
            echo "    ";
        }
        // line 9
        echo "
    <p>
        The requested page couldn't be located. Checkout for any URL
        misspelling or <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">return to the homepage</a>.
    </p>
";
        
        $__internal_7e887013ebad1b28a31d9188d58cd21939870087a07708e6e4d4bb9b0d541e10->leave($__internal_7e887013ebad1b28a31d9188d58cd21939870087a07708e6e4d4bb9b0d541e10_prof);

        
        $__internal_e712b0230889894b2c00d21fe6e2b308434481643e4a0c063c3e03a52db15194->leave($__internal_e712b0230889894b2c00d21fe6e2b308434481643e4a0c063c3e03a52db15194_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 12,  60 => 9,  57 => 8,  55 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Page not found - 404 error</h1>

    {% if is_granted('IS_AUTHENTICATED_FULLY') %}
        {# ... #}
    {% endif %}

    <p>
        The requested page couldn't be located. Checkout for any URL
        misspelling or <a href=\"{{ path('homepage') }}\">return to the homepage</a>.
    </p>
{% endblock %}", "@Twig/Exception/error404.html.twig", "/var/www/bus4you/app/Resources/TwigBundle/views/Exception/error404.html.twig");
    }
}
