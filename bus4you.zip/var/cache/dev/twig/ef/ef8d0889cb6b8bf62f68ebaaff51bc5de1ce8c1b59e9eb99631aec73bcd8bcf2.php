<?php

/* SonataAdminBundle:CRUD:list_inner_row.html.twig */
class __TwigTemplate_414ba07852bb6a94d41dbe99d00dbc9a8965dbd5b407cfea97bd9e7adfbea3d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataAdminBundle:CRUD:base_list_inner_row.html.twig", "SonataAdminBundle:CRUD:list_inner_row.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataAdminBundle:CRUD:base_list_inner_row.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b8e8fc67e7970bf9b1f96848565353e4ae23a1db3c80c87a1e7dbf10744eb77 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b8e8fc67e7970bf9b1f96848565353e4ae23a1db3c80c87a1e7dbf10744eb77->enter($__internal_9b8e8fc67e7970bf9b1f96848565353e4ae23a1db3c80c87a1e7dbf10744eb77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_inner_row.html.twig"));

        $__internal_b687849d4b35b846cb1b662c3081fc2f3129bff687dfe7ed1b668a8edf857104 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b687849d4b35b846cb1b662c3081fc2f3129bff687dfe7ed1b668a8edf857104->enter($__internal_b687849d4b35b846cb1b662c3081fc2f3129bff687dfe7ed1b668a8edf857104_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_inner_row.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9b8e8fc67e7970bf9b1f96848565353e4ae23a1db3c80c87a1e7dbf10744eb77->leave($__internal_9b8e8fc67e7970bf9b1f96848565353e4ae23a1db3c80c87a1e7dbf10744eb77_prof);

        
        $__internal_b687849d4b35b846cb1b662c3081fc2f3129bff687dfe7ed1b668a8edf857104->leave($__internal_b687849d4b35b846cb1b662c3081fc2f3129bff687dfe7ed1b668a8edf857104_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:list_inner_row.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends 'SonataAdminBundle:CRUD:base_list_inner_row.html.twig' %}
", "SonataAdminBundle:CRUD:list_inner_row.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/list_inner_row.html.twig");
    }
}
