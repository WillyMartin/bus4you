<?php

/* SonataBlockBundle:Block:block_base.html.twig */
class __TwigTemplate_1311ab61f3cdd45577adf0172c4f2d24b20b133c4652960c0cda1a94e19085fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10de5b3bb407a582b164da00b1847ed928c173a4a2e77e05b4c3c9c1fcee8123 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_10de5b3bb407a582b164da00b1847ed928c173a4a2e77e05b4c3c9c1fcee8123->enter($__internal_10de5b3bb407a582b164da00b1847ed928c173a4a2e77e05b4c3c9c1fcee8123_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_base.html.twig"));

        $__internal_59c44c1350b3ca6252f79bd1427fdad474a89324ee4912b49d380ff9d8e92fb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59c44c1350b3ca6252f79bd1427fdad474a89324ee4912b49d380ff9d8e92fb4->enter($__internal_59c44c1350b3ca6252f79bd1427fdad474a89324ee4912b49d380ff9d8e92fb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_base.html.twig"));

        // line 11
        echo "<div id=\"cms-block-";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["block"]) || array_key_exists("block", $context) ? $context["block"] : (function () { throw new Twig_Error_Runtime('Variable "block" does not exist.', 11, $this->getSourceContext()); })()), "id", array()), "html", null, true);
        echo "\" class=\"cms-block cms-block-element\">
    ";
        // line 12
        $this->displayBlock('block', $context, $blocks);
        // line 13
        echo "</div>
";
        
        $__internal_10de5b3bb407a582b164da00b1847ed928c173a4a2e77e05b4c3c9c1fcee8123->leave($__internal_10de5b3bb407a582b164da00b1847ed928c173a4a2e77e05b4c3c9c1fcee8123_prof);

        
        $__internal_59c44c1350b3ca6252f79bd1427fdad474a89324ee4912b49d380ff9d8e92fb4->leave($__internal_59c44c1350b3ca6252f79bd1427fdad474a89324ee4912b49d380ff9d8e92fb4_prof);

    }

    // line 12
    public function block_block($context, array $blocks = array())
    {
        $__internal_cee517030c779ab4fef1205291dbaf02c510a7428d7cd9742c390938b1001645 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cee517030c779ab4fef1205291dbaf02c510a7428d7cd9742c390938b1001645->enter($__internal_cee517030c779ab4fef1205291dbaf02c510a7428d7cd9742c390938b1001645_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        $__internal_2c72f4eeb52de4d2b950da51ca19f88e0fb24752f3c49b00cef4974b47c60737 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c72f4eeb52de4d2b950da51ca19f88e0fb24752f3c49b00cef4974b47c60737->enter($__internal_2c72f4eeb52de4d2b950da51ca19f88e0fb24752f3c49b00cef4974b47c60737_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        echo "EMPTY CONTENT";
        
        $__internal_2c72f4eeb52de4d2b950da51ca19f88e0fb24752f3c49b00cef4974b47c60737->leave($__internal_2c72f4eeb52de4d2b950da51ca19f88e0fb24752f3c49b00cef4974b47c60737_prof);

        
        $__internal_cee517030c779ab4fef1205291dbaf02c510a7428d7cd9742c390938b1001645->leave($__internal_cee517030c779ab4fef1205291dbaf02c510a7428d7cd9742c390938b1001645_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 12,  33 => 13,  31 => 12,  26 => 11,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}
<div id=\"cms-block-{{ block.id }}\" class=\"cms-block cms-block-element\">
    {% block block %}EMPTY CONTENT{% endblock %}
</div>
", "SonataBlockBundle:Block:block_base.html.twig", "/var/www/bus4you/vendor/sonata-project/block-bundle/Resources/views/Block/block_base.html.twig");
    }
}
