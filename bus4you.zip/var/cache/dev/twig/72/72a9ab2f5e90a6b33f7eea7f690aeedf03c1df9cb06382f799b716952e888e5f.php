<?php

/* SonataAdminBundle:Pager:base_results.html.twig */
class __TwigTemplate_4c46cdd77242ec37a30e10b7290884eaa935c3083cedb0c8757c7cf02b12aacf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'num_pages' => array($this, 'block_num_pages'),
            'num_results' => array($this, 'block_num_results'),
            'max_per_page' => array($this, 'block_max_per_page'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c778d3c14641639599e884980eda71080736bc48b8387cb208978693c291d977 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c778d3c14641639599e884980eda71080736bc48b8387cb208978693c291d977->enter($__internal_c778d3c14641639599e884980eda71080736bc48b8387cb208978693c291d977_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:base_results.html.twig"));

        $__internal_f51450e1a672e9761804ec0e1c9b83d18502ca3cae51b1a28a8515cf0742dd7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f51450e1a672e9761804ec0e1c9b83d18502ca3cae51b1a28a8515cf0742dd7c->enter($__internal_f51450e1a672e9761804ec0e1c9b83d18502ca3cae51b1a28a8515cf0742dd7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:base_results.html.twig"));

        // line 11
        echo "
";
        // line 12
        $this->displayBlock('num_pages', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('num_results', $context, $blocks);
        // line 21
        echo "
";
        // line 22
        $this->displayBlock('max_per_page', $context, $blocks);
        
        $__internal_c778d3c14641639599e884980eda71080736bc48b8387cb208978693c291d977->leave($__internal_c778d3c14641639599e884980eda71080736bc48b8387cb208978693c291d977_prof);

        
        $__internal_f51450e1a672e9761804ec0e1c9b83d18502ca3cae51b1a28a8515cf0742dd7c->leave($__internal_f51450e1a672e9761804ec0e1c9b83d18502ca3cae51b1a28a8515cf0742dd7c_prof);

    }

    // line 12
    public function block_num_pages($context, array $blocks = array())
    {
        $__internal_cc348de2afe0cad81692c92ce41206d28995a368fcc402fc002a80c945666b80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc348de2afe0cad81692c92ce41206d28995a368fcc402fc002a80c945666b80->enter($__internal_cc348de2afe0cad81692c92ce41206d28995a368fcc402fc002a80c945666b80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "num_pages"));

        $__internal_cf3e2ad9d6c2fa5c5fa3f89205865c5828df88d1281d46251f9db47d74ecbd73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf3e2ad9d6c2fa5c5fa3f89205865c5828df88d1281d46251f9db47d74ecbd73->enter($__internal_cf3e2ad9d6c2fa5c5fa3f89205865c5828df88d1281d46251f9db47d74ecbd73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "num_pages"));

        // line 13
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 13, $this->getSourceContext()); })()), "datagrid", array()), "pager", array()), "page", array()), "html", null, true);
        echo " / ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 13, $this->getSourceContext()); })()), "datagrid", array()), "pager", array()), "lastpage", array()), "html", null, true);
        echo "
    &nbsp;-&nbsp;
";
        
        $__internal_cf3e2ad9d6c2fa5c5fa3f89205865c5828df88d1281d46251f9db47d74ecbd73->leave($__internal_cf3e2ad9d6c2fa5c5fa3f89205865c5828df88d1281d46251f9db47d74ecbd73_prof);

        
        $__internal_cc348de2afe0cad81692c92ce41206d28995a368fcc402fc002a80c945666b80->leave($__internal_cc348de2afe0cad81692c92ce41206d28995a368fcc402fc002a80c945666b80_prof);

    }

    // line 17
    public function block_num_results($context, array $blocks = array())
    {
        $__internal_1163c2a1f3d09050884fc85237a121b9ecf0bc9dd9d73dde852da506eac0f65f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1163c2a1f3d09050884fc85237a121b9ecf0bc9dd9d73dde852da506eac0f65f->enter($__internal_1163c2a1f3d09050884fc85237a121b9ecf0bc9dd9d73dde852da506eac0f65f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "num_results"));

        $__internal_c79b4318b49cffd499c143e99a27b94af3fbcf8befed5a327b4f24d6fe342a95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c79b4318b49cffd499c143e99a27b94af3fbcf8befed5a327b4f24d6fe342a95->enter($__internal_c79b4318b49cffd499c143e99a27b94af3fbcf8befed5a327b4f24d6fe342a95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "num_results"));

        // line 18
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->transChoice("list_results_count", twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 18, $this->getSourceContext()); })()), "datagrid", array()), "pager", array()), "nbresults", array()), array("%count%" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 18, $this->getSourceContext()); })()), "datagrid", array()), "pager", array()), "nbresults", array())), "SonataAdminBundle");
        // line 19
        echo "    &nbsp;-&nbsp;
";
        
        $__internal_c79b4318b49cffd499c143e99a27b94af3fbcf8befed5a327b4f24d6fe342a95->leave($__internal_c79b4318b49cffd499c143e99a27b94af3fbcf8befed5a327b4f24d6fe342a95_prof);

        
        $__internal_1163c2a1f3d09050884fc85237a121b9ecf0bc9dd9d73dde852da506eac0f65f->leave($__internal_1163c2a1f3d09050884fc85237a121b9ecf0bc9dd9d73dde852da506eac0f65f_prof);

    }

    // line 22
    public function block_max_per_page($context, array $blocks = array())
    {
        $__internal_a53dc8575d1008d7cf75c4b31e5baaee014b87122451a2bd40e134c10be9e442 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a53dc8575d1008d7cf75c4b31e5baaee014b87122451a2bd40e134c10be9e442->enter($__internal_a53dc8575d1008d7cf75c4b31e5baaee014b87122451a2bd40e134c10be9e442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "max_per_page"));

        $__internal_5ab47d5a10794c7c953bd8a0630d2852eacbf521d8decc4cb88fbdb16a2dec9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ab47d5a10794c7c953bd8a0630d2852eacbf521d8decc4cb88fbdb16a2dec9a->enter($__internal_5ab47d5a10794c7c953bd8a0630d2852eacbf521d8decc4cb88fbdb16a2dec9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "max_per_page"));

        // line 23
        echo "    <label class=\"control-label\" for=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 23, $this->getSourceContext()); })()), "uniqid", array()), "html", null, true);
        echo "_per_page\">";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("label_per_page", array(), "SonataAdminBundle");
        echo "</label>
    <select class=\"per-page small form-control\" id=\"";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 24, $this->getSourceContext()); })()), "uniqid", array()), "html", null, true);
        echo "_per_page\" style=\"width: auto\">
        ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 25, $this->getSourceContext()); })()), "getperpageoptions", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["per_page"]) {
            // line 26
            echo "            <option ";
            if (($context["per_page"] == twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 26, $this->getSourceContext()); })()), "datagrid", array()), "pager", array()), "maxperpage", array()))) {
                echo "selected=\"selected\"";
            }
            echo " value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 26, $this->getSourceContext()); })()), "generateUrl", array(0 => "list", 1 => array("filter" => twig_array_merge(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 26, $this->getSourceContext()); })()), "datagrid", array()), "values", array()), array("_page" => 1, "_per_page" => $context["per_page"])))), "method"), "html", null, true);
            echo "\">";
            // line 27
            echo twig_escape_filter($this->env, $context["per_page"], "html", null, true);
            // line 28
            echo "</option>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['per_page'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "    </select>
";
        
        $__internal_5ab47d5a10794c7c953bd8a0630d2852eacbf521d8decc4cb88fbdb16a2dec9a->leave($__internal_5ab47d5a10794c7c953bd8a0630d2852eacbf521d8decc4cb88fbdb16a2dec9a_prof);

        
        $__internal_a53dc8575d1008d7cf75c4b31e5baaee014b87122451a2bd40e134c10be9e442->leave($__internal_a53dc8575d1008d7cf75c4b31e5baaee014b87122451a2bd40e134c10be9e442_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Pager:base_results.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  140 => 30,  133 => 28,  131 => 27,  123 => 26,  119 => 25,  115 => 24,  108 => 23,  99 => 22,  88 => 19,  85 => 18,  76 => 17,  60 => 13,  51 => 12,  41 => 22,  38 => 21,  36 => 17,  33 => 16,  31 => 12,  28 => 11,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% block num_pages %}
    {{ admin.datagrid.pager.page }} / {{ admin.datagrid.pager.lastpage }}
    &nbsp;-&nbsp;
{% endblock %}

{% block num_results %}
    {% transchoice admin.datagrid.pager.nbresults with {'%count%': admin.datagrid.pager.nbresults} from 'SonataAdminBundle' %}list_results_count{% endtranschoice %}
    &nbsp;-&nbsp;
{% endblock %}

{% block max_per_page %}
    <label class=\"control-label\" for=\"{{ admin.uniqid }}_per_page\">{% trans from 'SonataAdminBundle' %}label_per_page{% endtrans %}</label>
    <select class=\"per-page small form-control\" id=\"{{ admin.uniqid }}_per_page\" style=\"width: auto\">
        {% for per_page in admin.getperpageoptions %}
            <option {% if per_page == admin.datagrid.pager.maxperpage %}selected=\"selected\"{% endif %} value=\"{{ admin.generateUrl('list', {'filter': admin.datagrid.values|merge({'_page': 1, '_per_page': per_page})}) }}\">
                {{- per_page -}}
            </option>
        {% endfor %}
    </select>
{% endblock %}
", "SonataAdminBundle:Pager:base_results.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/Pager/base_results.html.twig");
    }
}
