<?php

/* knp_menu_base.html.twig */
class __TwigTemplate_49d40ee728f4a343332db1281abc458beea9d25245b2dfd066775094546a384a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e1984e89349572e5a7c554a077058228848e2d9471d8cdfd03af485538cd48d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e1984e89349572e5a7c554a077058228848e2d9471d8cdfd03af485538cd48d->enter($__internal_1e1984e89349572e5a7c554a077058228848e2d9471d8cdfd03af485538cd48d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        $__internal_02b5cd6483b83f8edc5bb7eadea4fd9e891762e05010f11acc9baeb5f4b087a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02b5cd6483b83f8edc5bb7eadea4fd9e891762e05010f11acc9baeb5f4b087a6->enter($__internal_02b5cd6483b83f8edc5bb7eadea4fd9e891762e05010f11acc9baeb5f4b087a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        // line 1
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new Twig_Error_Runtime('Variable "options" does not exist.', 1, $this->getSourceContext()); })()), "compressed", array())) {
            $this->displayBlock("compressed_root", $context, $blocks);
        } else {
            $this->displayBlock("root", $context, $blocks);
        }
        
        $__internal_1e1984e89349572e5a7c554a077058228848e2d9471d8cdfd03af485538cd48d->leave($__internal_1e1984e89349572e5a7c554a077058228848e2d9471d8cdfd03af485538cd48d_prof);

        
        $__internal_02b5cd6483b83f8edc5bb7eadea4fd9e891762e05010f11acc9baeb5f4b087a6->leave($__internal_02b5cd6483b83f8edc5bb7eadea4fd9e891762e05010f11acc9baeb5f4b087a6_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if options.compressed %}{{ block('compressed_root') }}{% else %}{{ block('root') }}{% endif %}
", "knp_menu_base.html.twig", "/var/www/bus4you/vendor/knplabs/knp-menu/src/Knp/Menu/Resources/views/knp_menu_base.html.twig");
    }
}
