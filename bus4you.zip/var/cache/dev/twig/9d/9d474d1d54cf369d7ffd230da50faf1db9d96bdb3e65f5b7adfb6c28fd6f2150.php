<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_1312a2c11c8efa106459e4ac4a098f6d984c704445b9507d48e563e2da254a44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9ccda83acc3d8ffa4bd3b7889c3349a68e4b1ac2aaa57cbbcf19f3e2007c4c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9ccda83acc3d8ffa4bd3b7889c3349a68e4b1ac2aaa57cbbcf19f3e2007c4c4->enter($__internal_a9ccda83acc3d8ffa4bd3b7889c3349a68e4b1ac2aaa57cbbcf19f3e2007c4c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5a361a0c9e4b3b821821db076d17b3737c68d78274431cf79bb9b61bfd978f91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a361a0c9e4b3b821821db076d17b3737c68d78274431cf79bb9b61bfd978f91->enter($__internal_5a361a0c9e4b3b821821db076d17b3737c68d78274431cf79bb9b61bfd978f91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a9ccda83acc3d8ffa4bd3b7889c3349a68e4b1ac2aaa57cbbcf19f3e2007c4c4->leave($__internal_a9ccda83acc3d8ffa4bd3b7889c3349a68e4b1ac2aaa57cbbcf19f3e2007c4c4_prof);

        
        $__internal_5a361a0c9e4b3b821821db076d17b3737c68d78274431cf79bb9b61bfd978f91->leave($__internal_5a361a0c9e4b3b821821db076d17b3737c68d78274431cf79bb9b61bfd978f91_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_63deed0c28f3a509b93984b5153428f93a5122a3a03d3d0138f7f739b5be115a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63deed0c28f3a509b93984b5153428f93a5122a3a03d3d0138f7f739b5be115a->enter($__internal_63deed0c28f3a509b93984b5153428f93a5122a3a03d3d0138f7f739b5be115a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_8e3a8fad7e93d8795f37e6e8772ea1bbb82f755f319f5ec10f0367a5a18c62c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e3a8fad7e93d8795f37e6e8772ea1bbb82f755f319f5ec10f0367a5a18c62c0->enter($__internal_8e3a8fad7e93d8795f37e6e8772ea1bbb82f755f319f5ec10f0367a5a18c62c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_8e3a8fad7e93d8795f37e6e8772ea1bbb82f755f319f5ec10f0367a5a18c62c0->leave($__internal_8e3a8fad7e93d8795f37e6e8772ea1bbb82f755f319f5ec10f0367a5a18c62c0_prof);

        
        $__internal_63deed0c28f3a509b93984b5153428f93a5122a3a03d3d0138f7f739b5be115a->leave($__internal_63deed0c28f3a509b93984b5153428f93a5122a3a03d3d0138f7f739b5be115a_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5513011a9434d48e5bf1190cd2c977475165e5cd44b41304b0ba94af425419ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5513011a9434d48e5bf1190cd2c977475165e5cd44b41304b0ba94af425419ab->enter($__internal_5513011a9434d48e5bf1190cd2c977475165e5cd44b41304b0ba94af425419ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_5d1f2298ca75cbe7a737560c21643e3fe52dcf70ae871c78d428be505733105e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d1f2298ca75cbe7a737560c21643e3fe52dcf70ae871c78d428be505733105e->enter($__internal_5d1f2298ca75cbe7a737560c21643e3fe52dcf70ae871c78d428be505733105e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_5d1f2298ca75cbe7a737560c21643e3fe52dcf70ae871c78d428be505733105e->leave($__internal_5d1f2298ca75cbe7a737560c21643e3fe52dcf70ae871c78d428be505733105e_prof);

        
        $__internal_5513011a9434d48e5bf1190cd2c977475165e5cd44b41304b0ba94af425419ab->leave($__internal_5513011a9434d48e5bf1190cd2c977475165e5cd44b41304b0ba94af425419ab_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_20a6da2547199d649879ee0a2fca61f585528e72162ab2a9bda9ec03fd3b6add = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20a6da2547199d649879ee0a2fca61f585528e72162ab2a9bda9ec03fd3b6add->enter($__internal_20a6da2547199d649879ee0a2fca61f585528e72162ab2a9bda9ec03fd3b6add_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_0477c6149b40ba59de6047a0007d7b03cf91cb45c68c26ae8a91407de5f0cac1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0477c6149b40ba59de6047a0007d7b03cf91cb45c68c26ae8a91407de5f0cac1->enter($__internal_0477c6149b40ba59de6047a0007d7b03cf91cb45c68c26ae8a91407de5f0cac1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_0477c6149b40ba59de6047a0007d7b03cf91cb45c68c26ae8a91407de5f0cac1->leave($__internal_0477c6149b40ba59de6047a0007d7b03cf91cb45c68c26ae8a91407de5f0cac1_prof);

        
        $__internal_20a6da2547199d649879ee0a2fca61f585528e72162ab2a9bda9ec03fd3b6add->leave($__internal_20a6da2547199d649879ee0a2fca61f585528e72162ab2a9bda9ec03fd3b6add_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
