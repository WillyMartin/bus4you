<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_16b9941e0712e3c3eeda18f665adc220e71767a2a292af1cf6e4674fc012f6c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4f019fd70e8536e6b680850210221116141f42d463182f0a625508c95a58555 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4f019fd70e8536e6b680850210221116141f42d463182f0a625508c95a58555->enter($__internal_b4f019fd70e8536e6b680850210221116141f42d463182f0a625508c95a58555_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_fdf211c1d5d6db57e0a1b9301eaca63ab9b2c9de85d61ef2369f08f445171ced = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdf211c1d5d6db57e0a1b9301eaca63ab9b2c9de85d61ef2369f08f445171ced->enter($__internal_fdf211c1d5d6db57e0a1b9301eaca63ab9b2c9de85d61ef2369f08f445171ced_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4f019fd70e8536e6b680850210221116141f42d463182f0a625508c95a58555->leave($__internal_b4f019fd70e8536e6b680850210221116141f42d463182f0a625508c95a58555_prof);

        
        $__internal_fdf211c1d5d6db57e0a1b9301eaca63ab9b2c9de85d61ef2369f08f445171ced->leave($__internal_fdf211c1d5d6db57e0a1b9301eaca63ab9b2c9de85d61ef2369f08f445171ced_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_3cb41c6bb9b1392b4db15f104ecffd237163a12bca4168fdbf6978d64c36bc4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3cb41c6bb9b1392b4db15f104ecffd237163a12bca4168fdbf6978d64c36bc4a->enter($__internal_3cb41c6bb9b1392b4db15f104ecffd237163a12bca4168fdbf6978d64c36bc4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_3c553a94264c4ed7ff26075d34840d924049632bb840b28211844333b93ab7a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c553a94264c4ed7ff26075d34840d924049632bb840b28211844333b93ab7a9->enter($__internal_3c553a94264c4ed7ff26075d34840d924049632bb840b28211844333b93ab7a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_3c553a94264c4ed7ff26075d34840d924049632bb840b28211844333b93ab7a9->leave($__internal_3c553a94264c4ed7ff26075d34840d924049632bb840b28211844333b93ab7a9_prof);

        
        $__internal_3cb41c6bb9b1392b4db15f104ecffd237163a12bca4168fdbf6978d64c36bc4a->leave($__internal_3cb41c6bb9b1392b4db15f104ecffd237163a12bca4168fdbf6978d64c36bc4a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/ajax.html.twig");
    }
}
