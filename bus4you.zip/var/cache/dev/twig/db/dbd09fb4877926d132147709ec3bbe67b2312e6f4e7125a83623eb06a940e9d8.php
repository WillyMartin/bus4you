<?php

/* default/login.html.twig */
class __TwigTemplate_8d5d482337f1caed396cd16d29286c0a551a8f7c1e3819366c8c100ffc70ac49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_784c15641078ffed5de02ef61f3eca98f26e4d7cd08385371027df1735ccb288 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_784c15641078ffed5de02ef61f3eca98f26e4d7cd08385371027df1735ccb288->enter($__internal_784c15641078ffed5de02ef61f3eca98f26e4d7cd08385371027df1735ccb288_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $__internal_ac11d21af7b1580d068a3f60e6724c238d74b654dc9a7d6a796d8c188f005c42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac11d21af7b1580d068a3f60e6724c238d74b654dc9a7d6a796d8c188f005c42->enter($__internal_ac11d21af7b1580d068a3f60e6724c238d74b654dc9a7d6a796d8c188f005c42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_784c15641078ffed5de02ef61f3eca98f26e4d7cd08385371027df1735ccb288->leave($__internal_784c15641078ffed5de02ef61f3eca98f26e4d7cd08385371027df1735ccb288_prof);

        
        $__internal_ac11d21af7b1580d068a3f60e6724c238d74b654dc9a7d6a796d8c188f005c42->leave($__internal_ac11d21af7b1580d068a3f60e6724c238d74b654dc9a7d6a796d8c188f005c42_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4f71eadf2d25c6d6b3502e93bd2f0373188ccf80fe400390eb2a87b3d071206c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f71eadf2d25c6d6b3502e93bd2f0373188ccf80fe400390eb2a87b3d071206c->enter($__internal_4f71eadf2d25c6d6b3502e93bd2f0373188ccf80fe400390eb2a87b3d071206c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b1b39cd4684bf6700513bd3d4ff76cecafe2e4624545ddccb688d8710b80d5d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1b39cd4684bf6700513bd3d4ff76cecafe2e4624545ddccb688d8710b80d5d0->enter($__internal_b1b39cd4684bf6700513bd3d4ff76cecafe2e4624545ddccb688d8710b80d5d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "FOSUserBundle:Security:login_content.html.twig");
        echo "
";
        
        $__internal_b1b39cd4684bf6700513bd3d4ff76cecafe2e4624545ddccb688d8710b80d5d0->leave($__internal_b1b39cd4684bf6700513bd3d4ff76cecafe2e4624545ddccb688d8710b80d5d0_prof);

        
        $__internal_4f71eadf2d25c6d6b3502e93bd2f0373188ccf80fe400390eb2a87b3d071206c->leave($__internal_4f71eadf2d25c6d6b3502e93bd2f0373188ccf80fe400390eb2a87b3d071206c_prof);

    }

    public function getTemplateName()
    {
        return "default/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block body %}
    {{ include('FOSUserBundle:Security:login_content.html.twig') }}
{% endblock %}
", "default/login.html.twig", "/var/www/bus4you/app/Resources/views/default/login.html.twig");
    }
}
