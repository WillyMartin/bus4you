<?php

/* SonataAdminBundle:CRUD:list_boolean.html.twig */
class __TwigTemplate_046b4c4850567ba2387f0ab67b0005db7270f450eb9661d63de2c0bcc117ffed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field_span_attributes' => array($this, 'block_field_span_attributes'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 12, $this->getSourceContext()); })()), "getTemplate", array(0 => "base_list_field"), "method"), "SonataAdminBundle:CRUD:list_boolean.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a45461afe9be985acdef8f61072eaae522af7add72974edd1423d9f050805a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a45461afe9be985acdef8f61072eaae522af7add72974edd1423d9f050805a8->enter($__internal_8a45461afe9be985acdef8f61072eaae522af7add72974edd1423d9f050805a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_boolean.html.twig"));

        $__internal_3c0c4f6d762166d57cfe7c17d6d9d19c0477a0c2d841d42ab7a5b22455642b75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c0c4f6d762166d57cfe7c17d6d9d19c0477a0c2d841d42ab7a5b22455642b75->enter($__internal_3c0c4f6d762166d57cfe7c17d6d9d19c0477a0c2d841d42ab7a5b22455642b75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_boolean.html.twig"));

        // line 14
        $context["isEditable"] = ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["field_description"] ?? null), "options", array(), "any", false, true), "editable", array(), "any", true, true) && twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["field_description"]) || array_key_exists("field_description", $context) ? $context["field_description"] : (function () { throw new Twig_Error_Runtime('Variable "field_description" does not exist.', 14, $this->getSourceContext()); })()), "options", array()), "editable", array())) && twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 14, $this->getSourceContext()); })()), "hasAccess", array(0 => "edit", 1 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 14, $this->getSourceContext()); })())), "method"));
        // line 15
        $context["xEditableType"] = $this->env->getExtension('Sonata\AdminBundle\Twig\Extension\SonataAdminExtension')->getXEditableType(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["field_description"]) || array_key_exists("field_description", $context) ? $context["field_description"] : (function () { throw new Twig_Error_Runtime('Variable "field_description" does not exist.', 15, $this->getSourceContext()); })()), "type", array()));
        // line 17
        if (((isset($context["isEditable"]) || array_key_exists("isEditable", $context) ? $context["isEditable"] : (function () { throw new Twig_Error_Runtime('Variable "isEditable" does not exist.', 17, $this->getSourceContext()); })()) && (isset($context["xEditableType"]) || array_key_exists("xEditableType", $context) ? $context["xEditableType"] : (function () { throw new Twig_Error_Runtime('Variable "xEditableType" does not exist.', 17, $this->getSourceContext()); })()))) {
        }
        // line 12
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a45461afe9be985acdef8f61072eaae522af7add72974edd1423d9f050805a8->leave($__internal_8a45461afe9be985acdef8f61072eaae522af7add72974edd1423d9f050805a8_prof);

        
        $__internal_3c0c4f6d762166d57cfe7c17d6d9d19c0477a0c2d841d42ab7a5b22455642b75->leave($__internal_3c0c4f6d762166d57cfe7c17d6d9d19c0477a0c2d841d42ab7a5b22455642b75_prof);

    }

    // line 18
    public function block_field_span_attributes($context, array $blocks = array())
    {
        $__internal_e58fa4fcaad886f1904c5ff5f65c09486c4c91b434454dc04e7647dc907c594c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e58fa4fcaad886f1904c5ff5f65c09486c4c91b434454dc04e7647dc907c594c->enter($__internal_e58fa4fcaad886f1904c5ff5f65c09486c4c91b434454dc04e7647dc907c594c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field_span_attributes"));

        $__internal_2f342226a60793f396c719dca6702dc6e28ad9913b0c97046729d357b6cdbb47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f342226a60793f396c719dca6702dc6e28ad9913b0c97046729d357b6cdbb47->enter($__internal_2f342226a60793f396c719dca6702dc6e28ad9913b0c97046729d357b6cdbb47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field_span_attributes"));

        // line 19
        echo "        ";
        ob_start();
        // line 20
        echo "            ";
        $this->displayParentBlock("field_span_attributes", $context, $blocks);
        echo "
            data-source=\"[{value: 0, text: '";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("label_type_no", array(), "SonataAdminBundle");
        echo "'},{value: 1, text: '";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("label_type_yes", array(), "SonataAdminBundle");
        echo "'}]\"
        ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        // line 23
        echo "    ";
        
        $__internal_2f342226a60793f396c719dca6702dc6e28ad9913b0c97046729d357b6cdbb47->leave($__internal_2f342226a60793f396c719dca6702dc6e28ad9913b0c97046729d357b6cdbb47_prof);

        
        $__internal_e58fa4fcaad886f1904c5ff5f65c09486c4c91b434454dc04e7647dc907c594c->leave($__internal_e58fa4fcaad886f1904c5ff5f65c09486c4c91b434454dc04e7647dc907c594c_prof);

    }

    // line 26
    public function block_field($context, array $blocks = array())
    {
        $__internal_f6495f2ec52bff104a4f8f634289c91305b497a6c5767b6009b121f9145acd52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6495f2ec52bff104a4f8f634289c91305b497a6c5767b6009b121f9145acd52->enter($__internal_f6495f2ec52bff104a4f8f634289c91305b497a6c5767b6009b121f9145acd52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        $__internal_8721afdb6b405130ee337d2b4d1c8c6d256ea58617e61db071fa8f0c9c9678f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8721afdb6b405130ee337d2b4d1c8c6d256ea58617e61db071fa8f0c9c9678f2->enter($__internal_8721afdb6b405130ee337d2b4d1c8c6d256ea58617e61db071fa8f0c9c9678f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 27
        echo "    ";
        ob_start();
        // line 28
        echo "        ";
        if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 28, $this->getSourceContext()); })())) {
            // line 29
            echo "            <span class=\"label label-success\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("label_type_yes", array(), "SonataAdminBundle");
            echo "</span>
        ";
        } else {
            // line 31
            echo "            <span class=\"label label-danger\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("label_type_no", array(), "SonataAdminBundle");
            echo "</span>
        ";
        }
        // line 33
        echo "    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_8721afdb6b405130ee337d2b4d1c8c6d256ea58617e61db071fa8f0c9c9678f2->leave($__internal_8721afdb6b405130ee337d2b4d1c8c6d256ea58617e61db071fa8f0c9c9678f2_prof);

        
        $__internal_f6495f2ec52bff104a4f8f634289c91305b497a6c5767b6009b121f9145acd52->leave($__internal_f6495f2ec52bff104a4f8f634289c91305b497a6c5767b6009b121f9145acd52_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:list_boolean.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 33,  103 => 31,  97 => 29,  94 => 28,  91 => 27,  82 => 26,  72 => 23,  65 => 21,  60 => 20,  57 => 19,  48 => 18,  38 => 12,  35 => 17,  33 => 15,  31 => 14,  19 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends admin.getTemplate('base_list_field') %}

{% set isEditable = field_description.options.editable is defined and field_description.options.editable and admin.hasAccess('edit', object) %}
{% set xEditableType = field_description.type|sonata_xeditable_type %}

{% if isEditable and xEditableType %}
    {% block field_span_attributes %}
        {% spaceless %}
            {{ parent() }}
            data-source=\"[{value: 0, text: '{%- trans from 'SonataAdminBundle' %}label_type_no{% endtrans -%}'},{value: 1, text: '{%- trans from 'SonataAdminBundle' %}label_type_yes{% endtrans -%}'}]\"
        {% endspaceless %}
    {% endblock %}
{% endif %}

{% block field %}
    {% spaceless %}
        {% if value %}
            <span class=\"label label-success\">{%- trans from 'SonataAdminBundle' %}label_type_yes{% endtrans -%}</span>
        {% else %}
            <span class=\"label label-danger\">{%- trans from 'SonataAdminBundle' %}label_type_no{% endtrans -%}</span>
        {% endif %}
    {% endspaceless %}
{% endblock %}
", "SonataAdminBundle:CRUD:list_boolean.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/list_boolean.html.twig");
    }
}
