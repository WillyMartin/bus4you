<?php

/* SonataFormatterBundle:Form:ckeditor.html.twig */
class __TwigTemplate_6372d37dc39f81d774b17b26806023ec06c30f44e8275b228d4ea859f920d7f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_094cbf0719233d989e1bc48e30abc85c075958265d25af694e27fc110663b171 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_094cbf0719233d989e1bc48e30abc85c075958265d25af694e27fc110663b171->enter($__internal_094cbf0719233d989e1bc48e30abc85c075958265d25af694e27fc110663b171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataFormatterBundle:Form:ckeditor.html.twig"));

        $__internal_feda1b83f929857d079f6b599d311c7d8d3126db41bbf6d85586ae12cc976d2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feda1b83f929857d079f6b599d311c7d8d3126db41bbf6d85586ae12cc976d2a->enter($__internal_feda1b83f929857d079f6b599d311c7d8d3126db41bbf6d85586ae12cc976d2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataFormatterBundle:Form:ckeditor.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ckeditor_plugins"]) || array_key_exists("ckeditor_plugins", $context) ? $context["ckeditor_plugins"] : (function () { throw new Twig_Error_Runtime('Variable "ckeditor_plugins" does not exist.', 1, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["plugin_name"] => $context["plugin"]) {
            // line 2
            echo "\t";
            echo $this->env->getExtension('Ivory\CKEditorBundle\Twig\CKEditorExtension')->renderPlugin($context["plugin_name"], $context["plugin"]);
            echo "
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['plugin_name'], $context['plugin'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 4
        echo "
";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ckeditor_templates"]) || array_key_exists("ckeditor_templates", $context) ? $context["ckeditor_templates"] : (function () { throw new Twig_Error_Runtime('Variable "ckeditor_templates" does not exist.', 5, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["template_name"] => $context["template"]) {
            // line 6
            echo "\t";
            echo $this->env->getExtension('Ivory\CKEditorBundle\Twig\CKEditorExtension')->renderTemplate($context["template_name"], $context["template"]);
            echo "
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['template_name'], $context['template'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "
";
        // line 9
        echo $this->env->getExtension('Ivory\CKEditorBundle\Twig\CKEditorExtension')->renderWidget((isset($context["ckeditor_field_id"]) || array_key_exists("ckeditor_field_id", $context) ? $context["ckeditor_field_id"] : (function () { throw new Twig_Error_Runtime('Variable "ckeditor_field_id" does not exist.', 9, $this->getSourceContext()); })()), (isset($context["ckeditor_configuration"]) || array_key_exists("ckeditor_configuration", $context) ? $context["ckeditor_configuration"] : (function () { throw new Twig_Error_Runtime('Variable "ckeditor_configuration" does not exist.', 9, $this->getSourceContext()); })()), array("input_sync" => true));
        // line 11
        echo "
";
        
        $__internal_094cbf0719233d989e1bc48e30abc85c075958265d25af694e27fc110663b171->leave($__internal_094cbf0719233d989e1bc48e30abc85c075958265d25af694e27fc110663b171_prof);

        
        $__internal_feda1b83f929857d079f6b599d311c7d8d3126db41bbf6d85586ae12cc976d2a->leave($__internal_feda1b83f929857d079f6b599d311c7d8d3126db41bbf6d85586ae12cc976d2a_prof);

    }

    public function getTemplateName()
    {
        return "SonataFormatterBundle:Form:ckeditor.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 11,  57 => 9,  54 => 8,  45 => 6,  41 => 5,  38 => 4,  29 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% for plugin_name, plugin in ckeditor_plugins %}
\t{{ ckeditor_plugin(plugin_name, plugin) }}
{% endfor %}

{% for template_name, template in ckeditor_templates %}
\t{{ ckeditor_template(template_name, template) }}
{% endfor %}

{{ ckeditor_widget(ckeditor_field_id, ckeditor_configuration, {
\tinput_sync: true,
}) }}
", "SonataFormatterBundle:Form:ckeditor.html.twig", "/var/www/bus4you/vendor/sonata-project/formatter-bundle/Resources/views/Form/ckeditor.html.twig");
    }
}
