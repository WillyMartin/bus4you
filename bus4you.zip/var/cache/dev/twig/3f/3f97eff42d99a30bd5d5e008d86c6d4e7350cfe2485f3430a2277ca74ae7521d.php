<?php

/* SonataAdminBundle:CRUD:list.html.twig */
class __TwigTemplate_ac65cf2227916d4ff948ac960a7bc6b8a89223cf927894393c13f1b782bc77b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataAdminBundle:CRUD:base_list.html.twig", "SonataAdminBundle:CRUD:list.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataAdminBundle:CRUD:base_list.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aabab3cae92b53acdfb9701c4c093bda5207deeb066ff5c16a9e744194609ea6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aabab3cae92b53acdfb9701c4c093bda5207deeb066ff5c16a9e744194609ea6->enter($__internal_aabab3cae92b53acdfb9701c4c093bda5207deeb066ff5c16a9e744194609ea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list.html.twig"));

        $__internal_168211acd8da8d041d736dcd0d98e305193e38b7b6815f8e0a0f0aab6c907f2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_168211acd8da8d041d736dcd0d98e305193e38b7b6815f8e0a0f0aab6c907f2d->enter($__internal_168211acd8da8d041d736dcd0d98e305193e38b7b6815f8e0a0f0aab6c907f2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aabab3cae92b53acdfb9701c4c093bda5207deeb066ff5c16a9e744194609ea6->leave($__internal_aabab3cae92b53acdfb9701c4c093bda5207deeb066ff5c16a9e744194609ea6_prof);

        
        $__internal_168211acd8da8d041d736dcd0d98e305193e38b7b6815f8e0a0f0aab6c907f2d->leave($__internal_168211acd8da8d041d736dcd0d98e305193e38b7b6815f8e0a0f0aab6c907f2d_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends 'SonataAdminBundle:CRUD:base_list.html.twig' %}
", "SonataAdminBundle:CRUD:list.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/list.html.twig");
    }
}
