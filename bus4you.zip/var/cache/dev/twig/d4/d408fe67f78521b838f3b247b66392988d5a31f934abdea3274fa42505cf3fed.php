<?php

/* base.html.twig */
class __TwigTemplate_a8c80ee465d894887e3b031fd6b76d23bddfd99471f666d33781dc647a8c3257 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_396842aee977cafcb807b6e14f3ce91f696ca7835805bbf75d862bc7d1b00438 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_396842aee977cafcb807b6e14f3ce91f696ca7835805bbf75d862bc7d1b00438->enter($__internal_396842aee977cafcb807b6e14f3ce91f696ca7835805bbf75d862bc7d1b00438_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_68c1f03bcb1ef34561aea6feb080136c08876b5bc902f44e2d08b615913d7df3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68c1f03bcb1ef34561aea6feb080136c08876b5bc902f44e2d08b615913d7df3->enter($__internal_68c1f03bcb1ef34561aea6feb080136c08876b5bc902f44e2d08b615913d7df3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">

        <title>Title</title>
        <meta name=\"description\" content=\"\">

        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">

        <meta property=\"og:image\" content=\"path/to/image.jpg\">

        <link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-57x57.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"60x60\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-60x60.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-72x72.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"76x76\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-76x76.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-114x114.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"120x120\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-120x120.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-144x144.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"152x152\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-152x152.png"), "html", null, true);
        echo "\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/apple-icon-180x180.png"), "html", null, true);
        echo "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"192x192\"  href=\"/";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/android-icon-192x192.png"), "html", null, true);
        echo "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/favicon-32x32.png"), "html", null, true);
        echo "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"96x96\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/favicon-96x96.png"), "html", null, true);
        echo "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/favicon/favicon-16x16.png"), "html", null, true);
        echo "\">
        <link rel=\"manifest\" href=\"{ asset('assets/img/favicon/manifest.json') }}\">

        <!-- Chrome, Firefox OS and Opera -->
        <meta name=\"theme-color\" content=\"#000\">
        <!-- Windows Phone -->
        <meta name=\"msapplication-navbutton-color\" content=\"#000\">
        <!-- iOS Safari -->
        <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"#000\">

        <style>body { opacity: 0; overflow-x: hidden; } html { background-color: #fff; }</style>
        <link rel=\"stylesheet\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/main.min.css"), "html", null, true);
        echo "\">
        
    </head>
    <body>
        ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 42
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 43
        echo "
        <script src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/scripts.min.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>
";
        
        $__internal_396842aee977cafcb807b6e14f3ce91f696ca7835805bbf75d862bc7d1b00438->leave($__internal_396842aee977cafcb807b6e14f3ce91f696ca7835805bbf75d862bc7d1b00438_prof);

        
        $__internal_68c1f03bcb1ef34561aea6feb080136c08876b5bc902f44e2d08b615913d7df3->leave($__internal_68c1f03bcb1ef34561aea6feb080136c08876b5bc902f44e2d08b615913d7df3_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_56b180a1c69943f65f8717046b61632e46867065ffbea53f51d520d10c146ccd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56b180a1c69943f65f8717046b61632e46867065ffbea53f51d520d10c146ccd->enter($__internal_56b180a1c69943f65f8717046b61632e46867065ffbea53f51d520d10c146ccd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0f3d3b2227aa9e40a42d1a5de75636ef6d3df54e64e83c5afb629e44ab4a2a33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f3d3b2227aa9e40a42d1a5de75636ef6d3df54e64e83c5afb629e44ab4a2a33->enter($__internal_0f3d3b2227aa9e40a42d1a5de75636ef6d3df54e64e83c5afb629e44ab4a2a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0f3d3b2227aa9e40a42d1a5de75636ef6d3df54e64e83c5afb629e44ab4a2a33->leave($__internal_0f3d3b2227aa9e40a42d1a5de75636ef6d3df54e64e83c5afb629e44ab4a2a33_prof);

        
        $__internal_56b180a1c69943f65f8717046b61632e46867065ffbea53f51d520d10c146ccd->leave($__internal_56b180a1c69943f65f8717046b61632e46867065ffbea53f51d520d10c146ccd_prof);

    }

    // line 42
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_326083e1fc7b78eaf3eb6f1fd193de56f06886a16e6f56d9f0e9e789c2aa7f4d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_326083e1fc7b78eaf3eb6f1fd193de56f06886a16e6f56d9f0e9e789c2aa7f4d->enter($__internal_326083e1fc7b78eaf3eb6f1fd193de56f06886a16e6f56d9f0e9e789c2aa7f4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_2b405fae0575853fffcee30b479ec0ccd8941ace348b2c7941d56a6b02e4844e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b405fae0575853fffcee30b479ec0ccd8941ace348b2c7941d56a6b02e4844e->enter($__internal_2b405fae0575853fffcee30b479ec0ccd8941ace348b2c7941d56a6b02e4844e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_2b405fae0575853fffcee30b479ec0ccd8941ace348b2c7941d56a6b02e4844e->leave($__internal_2b405fae0575853fffcee30b479ec0ccd8941ace348b2c7941d56a6b02e4844e_prof);

        
        $__internal_326083e1fc7b78eaf3eb6f1fd193de56f06886a16e6f56d9f0e9e789c2aa7f4d->leave($__internal_326083e1fc7b78eaf3eb6f1fd193de56f06886a16e6f56d9f0e9e789c2aa7f4d_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 42,  133 => 41,  119 => 44,  116 => 43,  113 => 42,  111 => 41,  104 => 37,  90 => 26,  86 => 25,  82 => 24,  78 => 23,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  58 => 18,  54 => 17,  50 => 16,  46 => 15,  42 => 14,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"utf-8\">

        <title>Title</title>
        <meta name=\"description\" content=\"\">

        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">

        <meta property=\"og:image\" content=\"path/to/image.jpg\">

        <link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"{{ asset('assets/img/favicon/apple-icon-57x57.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"60x60\" href=\"{{ asset('assets/img/favicon/apple-icon-60x60.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"{{ asset('assets/img/favicon/apple-icon-72x72.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"76x76\" href=\"{{ asset('assets/img/favicon/apple-icon-76x76.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"{{ asset('assets/img/favicon/apple-icon-114x114.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"120x120\" href=\"{{ asset('assets/img/favicon/apple-icon-120x120.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"{{ asset('assets/img/favicon/apple-icon-144x144.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"152x152\" href=\"{{ asset('assets/img/favicon/apple-icon-152x152.png') }}\">
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"{{ asset('assets/img/favicon/apple-icon-180x180.png') }}\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"192x192\"  href=\"/{{ asset('assets/img/favicon/android-icon-192x192.png') }}\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"{{ asset('assets/img/favicon/favicon-32x32.png') }}\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"96x96\" href=\"{{ asset('assets/img/favicon/favicon-96x96.png') }}\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"{{ asset('assets/img/favicon/favicon-16x16.png') }}\">
        <link rel=\"manifest\" href=\"{ asset('assets/img/favicon/manifest.json') }}\">

        <!-- Chrome, Firefox OS and Opera -->
        <meta name=\"theme-color\" content=\"#000\">
        <!-- Windows Phone -->
        <meta name=\"msapplication-navbutton-color\" content=\"#000\">
        <!-- iOS Safari -->
        <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"#000\">

        <style>body { opacity: 0; overflow-x: hidden; } html { background-color: #fff; }</style>
        <link rel=\"stylesheet\" href=\"{{ asset('assets/css/main.min.css') }}\">
        
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}

        <script src=\"{{ asset('assets/js/scripts.min.js') }}\"></script>
    </body>
</html>
", "base.html.twig", "/var/www/bus4you/app/Resources/views/base.html.twig");
    }
}
