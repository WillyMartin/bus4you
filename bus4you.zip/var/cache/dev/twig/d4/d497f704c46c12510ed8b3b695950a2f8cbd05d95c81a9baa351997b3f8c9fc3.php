<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_3aecfa7ea1e8f3789028a8d88f4e18178ef1182dff2cbb1de1bfc4b0a4cd200e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a60480103d98d47625d007f97560da4bfb9c79cdf2184d1dc8ff6571e1115c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a60480103d98d47625d007f97560da4bfb9c79cdf2184d1dc8ff6571e1115c8->enter($__internal_9a60480103d98d47625d007f97560da4bfb9c79cdf2184d1dc8ff6571e1115c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_2b91e594e60973595d7558d18ba3e276acf42262ba246d3bb68179d50efe5eb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b91e594e60973595d7558d18ba3e276acf42262ba246d3bb68179d50efe5eb7->enter($__internal_2b91e594e60973595d7558d18ba3e276acf42262ba246d3bb68179d50efe5eb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_9a60480103d98d47625d007f97560da4bfb9c79cdf2184d1dc8ff6571e1115c8->leave($__internal_9a60480103d98d47625d007f97560da4bfb9c79cdf2184d1dc8ff6571e1115c8_prof);

        
        $__internal_2b91e594e60973595d7558d18ba3e276acf42262ba246d3bb68179d50efe5eb7->leave($__internal_2b91e594e60973595d7558d18ba3e276acf42262ba246d3bb68179d50efe5eb7_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_b3b1febc9ed451c248c03ce496d759a63eccc441ac93f66cc31214cf5f06a52f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3b1febc9ed451c248c03ce496d759a63eccc441ac93f66cc31214cf5f06a52f->enter($__internal_b3b1febc9ed451c248c03ce496d759a63eccc441ac93f66cc31214cf5f06a52f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_7fbee13c81781206818e70a27c14dbc9813bbc52041ae295a70d1d57ea813bef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fbee13c81781206818e70a27c14dbc9813bbc52041ae295a70d1d57ea813bef->enter($__internal_7fbee13c81781206818e70a27c14dbc9813bbc52041ae295a70d1d57ea813bef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_7fbee13c81781206818e70a27c14dbc9813bbc52041ae295a70d1d57ea813bef->leave($__internal_7fbee13c81781206818e70a27c14dbc9813bbc52041ae295a70d1d57ea813bef_prof);

        
        $__internal_b3b1febc9ed451c248c03ce496d759a63eccc441ac93f66cc31214cf5f06a52f->leave($__internal_b3b1febc9ed451c248c03ce496d759a63eccc441ac93f66cc31214cf5f06a52f_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_f3626dced4e35939349ccfad39c6d32d6c16bca4f7b4a35200b005c157efea94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3626dced4e35939349ccfad39c6d32d6c16bca4f7b4a35200b005c157efea94->enter($__internal_f3626dced4e35939349ccfad39c6d32d6c16bca4f7b4a35200b005c157efea94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_caf3942ff659d4338956f524fff179bd595877a92d695c7db35d24fd740b9c6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_caf3942ff659d4338956f524fff179bd595877a92d695c7db35d24fd740b9c6d->enter($__internal_caf3942ff659d4338956f524fff179bd595877a92d695c7db35d24fd740b9c6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_caf3942ff659d4338956f524fff179bd595877a92d695c7db35d24fd740b9c6d->leave($__internal_caf3942ff659d4338956f524fff179bd595877a92d695c7db35d24fd740b9c6d_prof);

        
        $__internal_f3626dced4e35939349ccfad39c6d32d6c16bca4f7b4a35200b005c157efea94->leave($__internal_f3626dced4e35939349ccfad39c6d32d6c16bca4f7b4a35200b005c157efea94_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_23027beff87093ad76c70df2f6058fbbf143d7346e3e473f18e3cb3af13b4b88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23027beff87093ad76c70df2f6058fbbf143d7346e3e473f18e3cb3af13b4b88->enter($__internal_23027beff87093ad76c70df2f6058fbbf143d7346e3e473f18e3cb3af13b4b88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_979b007544a56b134fe54a7d38f3f1c257d0414d403c0911a460aff3fc09062a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_979b007544a56b134fe54a7d38f3f1c257d0414d403c0911a460aff3fc09062a->enter($__internal_979b007544a56b134fe54a7d38f3f1c257d0414d403c0911a460aff3fc09062a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_979b007544a56b134fe54a7d38f3f1c257d0414d403c0911a460aff3fc09062a->leave($__internal_979b007544a56b134fe54a7d38f3f1c257d0414d403c0911a460aff3fc09062a_prof);

        
        $__internal_23027beff87093ad76c70df2f6058fbbf143d7346e3e473f18e3cb3af13b4b88->leave($__internal_23027beff87093ad76c70df2f6058fbbf143d7346e3e473f18e3cb3af13b4b88_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/layout.html.twig");
    }
}
