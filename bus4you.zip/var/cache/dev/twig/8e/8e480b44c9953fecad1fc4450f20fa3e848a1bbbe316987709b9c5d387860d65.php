<?php

/* SonataAdminBundle:CRUD:list_date.html.twig */
class __TwigTemplate_220f8d601b79713e8edff9ab95e98a9a3c6159c3ad0be3711668e8c7758a9114 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 12, $this->getSourceContext()); })()), "getTemplate", array(0 => "base_list_field"), "method"), "SonataAdminBundle:CRUD:list_date.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92268472019ff9bb840d75e2bb2d7a90d0e48f98bc7b97da8cf7c12d35a7d256 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92268472019ff9bb840d75e2bb2d7a90d0e48f98bc7b97da8cf7c12d35a7d256->enter($__internal_92268472019ff9bb840d75e2bb2d7a90d0e48f98bc7b97da8cf7c12d35a7d256_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_date.html.twig"));

        $__internal_27bc390b3ac4fc50e3faec6851d83a2934301264008755b8cd0f72e11d3410c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27bc390b3ac4fc50e3faec6851d83a2934301264008755b8cd0f72e11d3410c5->enter($__internal_27bc390b3ac4fc50e3faec6851d83a2934301264008755b8cd0f72e11d3410c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:list_date.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_92268472019ff9bb840d75e2bb2d7a90d0e48f98bc7b97da8cf7c12d35a7d256->leave($__internal_92268472019ff9bb840d75e2bb2d7a90d0e48f98bc7b97da8cf7c12d35a7d256_prof);

        
        $__internal_27bc390b3ac4fc50e3faec6851d83a2934301264008755b8cd0f72e11d3410c5->leave($__internal_27bc390b3ac4fc50e3faec6851d83a2934301264008755b8cd0f72e11d3410c5_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_76538caeabbf0416d42bcffe168cfbdbd50ae4114e92220e98f257f4422128a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76538caeabbf0416d42bcffe168cfbdbd50ae4114e92220e98f257f4422128a4->enter($__internal_76538caeabbf0416d42bcffe168cfbdbd50ae4114e92220e98f257f4422128a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        $__internal_870babae0e1d97a524338777ba759109ce87451ca7ce558ffd3ca4aaa4eef46b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_870babae0e1d97a524338777ba759109ce87451ca7ce558ffd3ca4aaa4eef46b->enter($__internal_870babae0e1d97a524338777ba759109ce87451ca7ce558ffd3ca4aaa4eef46b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 15
        if (twig_test_empty((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 15, $this->getSourceContext()); })()))) {
            // line 16
            echo "&nbsp;";
        } elseif (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(),         // line 17
($context["field_description"] ?? null), "options", array(), "any", false, true), "format", array(), "any", true, true)) {
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 18, $this->getSourceContext()); })()), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["field_description"]) || array_key_exists("field_description", $context) ? $context["field_description"] : (function () { throw new Twig_Error_Runtime('Variable "field_description" does not exist.', 18, $this->getSourceContext()); })()), "options", array()), "format", array())), "html", null, true);
        } else {
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 20, $this->getSourceContext()); })()), "F j, Y"), "html", null, true);
        }
        
        $__internal_870babae0e1d97a524338777ba759109ce87451ca7ce558ffd3ca4aaa4eef46b->leave($__internal_870babae0e1d97a524338777ba759109ce87451ca7ce558ffd3ca4aaa4eef46b_prof);

        
        $__internal_76538caeabbf0416d42bcffe168cfbdbd50ae4114e92220e98f257f4422128a4->leave($__internal_76538caeabbf0416d42bcffe168cfbdbd50ae4114e92220e98f257f4422128a4_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:list_date.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 20,  54 => 18,  52 => 17,  50 => 16,  48 => 15,  39 => 14,  18 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends admin.getTemplate('base_list_field') %}

{% block field%}
    {%- if value is empty -%}
        &nbsp;
    {%- elseif field_description.options.format is defined -%}
        {{ value|date(field_description.options.format) }}
    {%- else -%}
        {{ value|date('F j, Y') }}
    {%- endif -%}
{% endblock %}
", "SonataAdminBundle:CRUD:list_date.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/list_date.html.twig");
    }
}
