<?php

/* SonataAdminBundle:CRUD:base_edit.html.twig */
class __TwigTemplate_2237dab434c803afcc37effbfb83c2963efa50db1d47127905fdb44471a81897 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $_trait_0 = $this->loadTemplate("SonataAdminBundle:CRUD:base_edit_form.html.twig", "SonataAdminBundle:CRUD:base_edit.html.twig", 32);
        // line 32
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."SonataAdminBundle:CRUD:base_edit_form.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        if (!isset($_trait_0_blocks["form"])) {
            throw new Twig_Error_Runtime(sprintf('Block "form" is not defined in trait "SonataAdminBundle:CRUD:base_edit_form.html.twig".'));
        }

        $_trait_0_blocks["parentForm"] = $_trait_0_blocks["form"]; unset($_trait_0_blocks["form"]);

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'title' => array($this, 'block_title'),
                'navbar_title' => array($this, 'block_navbar_title'),
                'actions' => array($this, 'block_actions'),
                'tab_menu' => array($this, 'block_tab_menu'),
                'form' => array($this, 'block_form'),
            )
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate((isset($context["base_template"]) || array_key_exists("base_template", $context) ? $context["base_template"] : (function () { throw new Twig_Error_Runtime('Variable "base_template" does not exist.', 12, $this->getSourceContext()); })()), "SonataAdminBundle:CRUD:base_edit.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76c6a8e3704a792df1d99a606b412cf6bcadc142da91d6afd6223f5ab57133d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76c6a8e3704a792df1d99a606b412cf6bcadc142da91d6afd6223f5ab57133d4->enter($__internal_76c6a8e3704a792df1d99a606b412cf6bcadc142da91d6afd6223f5ab57133d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:base_edit.html.twig"));

        $__internal_aedaeea5563820d0632231b562e08dc84681675510fc6f5361024144215dbb09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aedaeea5563820d0632231b562e08dc84681675510fc6f5361024144215dbb09->enter($__internal_aedaeea5563820d0632231b562e08dc84681675510fc6f5361024144215dbb09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:base_edit.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76c6a8e3704a792df1d99a606b412cf6bcadc142da91d6afd6223f5ab57133d4->leave($__internal_76c6a8e3704a792df1d99a606b412cf6bcadc142da91d6afd6223f5ab57133d4_prof);

        
        $__internal_aedaeea5563820d0632231b562e08dc84681675510fc6f5361024144215dbb09->leave($__internal_aedaeea5563820d0632231b562e08dc84681675510fc6f5361024144215dbb09_prof);

    }

    // line 14
    public function block_title($context, array $blocks = array())
    {
        $__internal_907a1ca5fd9ec2e3b374014cb020df03d5200597dd991822d3a8987a0607760b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_907a1ca5fd9ec2e3b374014cb020df03d5200597dd991822d3a8987a0607760b->enter($__internal_907a1ca5fd9ec2e3b374014cb020df03d5200597dd991822d3a8987a0607760b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_839ba3c06f52029707f7f3b2645311370ff112515c9f6bb7a585b7201837b692 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_839ba3c06f52029707f7f3b2645311370ff112515c9f6bb7a585b7201837b692->enter($__internal_839ba3c06f52029707f7f3b2645311370ff112515c9f6bb7a585b7201837b692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 15
        echo "    ";
        if ( !(null === twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 15, $this->getSourceContext()); })()), "id", array(0 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 15, $this->getSourceContext()); })())), "method"))) {
            // line 16
            echo "        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_edit", array("%name%" => twig_truncate_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 16, $this->getSourceContext()); })()), "toString", array(0 => (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 16, $this->getSourceContext()); })())), "method"), 15)), "SonataAdminBundle"), "html", null, true);
            echo "
    ";
        } else {
            // line 18
            echo "        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_create", array(), "SonataAdminBundle"), "html", null, true);
            echo "
    ";
        }
        
        $__internal_839ba3c06f52029707f7f3b2645311370ff112515c9f6bb7a585b7201837b692->leave($__internal_839ba3c06f52029707f7f3b2645311370ff112515c9f6bb7a585b7201837b692_prof);

        
        $__internal_907a1ca5fd9ec2e3b374014cb020df03d5200597dd991822d3a8987a0607760b->leave($__internal_907a1ca5fd9ec2e3b374014cb020df03d5200597dd991822d3a8987a0607760b_prof);

    }

    // line 22
    public function block_navbar_title($context, array $blocks = array())
    {
        $__internal_2da065605d220d2c2db42daae490d602e678ac3d249790a2a2e4c79dd3ddc93c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2da065605d220d2c2db42daae490d602e678ac3d249790a2a2e4c79dd3ddc93c->enter($__internal_2da065605d220d2c2db42daae490d602e678ac3d249790a2a2e4c79dd3ddc93c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar_title"));

        $__internal_e6a9faa56ab17bf5bfb0c2bbc859e75a14c9e5b3e1e35d3d54b0b724b617ec6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6a9faa56ab17bf5bfb0c2bbc859e75a14c9e5b3e1e35d3d54b0b724b617ec6a->enter($__internal_e6a9faa56ab17bf5bfb0c2bbc859e75a14c9e5b3e1e35d3d54b0b724b617ec6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar_title"));

        // line 23
        echo "    ";
        $this->displayBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_e6a9faa56ab17bf5bfb0c2bbc859e75a14c9e5b3e1e35d3d54b0b724b617ec6a->leave($__internal_e6a9faa56ab17bf5bfb0c2bbc859e75a14c9e5b3e1e35d3d54b0b724b617ec6a_prof);

        
        $__internal_2da065605d220d2c2db42daae490d602e678ac3d249790a2a2e4c79dd3ddc93c->leave($__internal_2da065605d220d2c2db42daae490d602e678ac3d249790a2a2e4c79dd3ddc93c_prof);

    }

    // line 26
    public function block_actions($context, array $blocks = array())
    {
        $__internal_5cc49af62688c6c16645bddd88fd9a94dd6be69b5ea02f0fbb24e42e4b1bd2e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cc49af62688c6c16645bddd88fd9a94dd6be69b5ea02f0fbb24e42e4b1bd2e6->enter($__internal_5cc49af62688c6c16645bddd88fd9a94dd6be69b5ea02f0fbb24e42e4b1bd2e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        $__internal_ed1a97bb8a196a9a9cbc106c513e54717b43d9d52ccc24c143ec55bf894383b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed1a97bb8a196a9a9cbc106c513e54717b43d9d52ccc24c143ec55bf894383b4->enter($__internal_ed1a97bb8a196a9a9cbc106c513e54717b43d9d52ccc24c143ec55bf894383b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        // line 27
        $this->loadTemplate("SonataAdminBundle:CRUD:action_buttons.html.twig", "SonataAdminBundle:CRUD:base_edit.html.twig", 27)->display($context);
        
        $__internal_ed1a97bb8a196a9a9cbc106c513e54717b43d9d52ccc24c143ec55bf894383b4->leave($__internal_ed1a97bb8a196a9a9cbc106c513e54717b43d9d52ccc24c143ec55bf894383b4_prof);

        
        $__internal_5cc49af62688c6c16645bddd88fd9a94dd6be69b5ea02f0fbb24e42e4b1bd2e6->leave($__internal_5cc49af62688c6c16645bddd88fd9a94dd6be69b5ea02f0fbb24e42e4b1bd2e6_prof);

    }

    // line 30
    public function block_tab_menu($context, array $blocks = array())
    {
        $__internal_6fa19cfa1579159e62b9ef8e2c5f974159ce2fb0026393201fb4ba8e4bf4be3f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6fa19cfa1579159e62b9ef8e2c5f974159ce2fb0026393201fb4ba8e4bf4be3f->enter($__internal_6fa19cfa1579159e62b9ef8e2c5f974159ce2fb0026393201fb4ba8e4bf4be3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        $__internal_b955b597a5e4f82480ac7bf4e2b727b33c7ec8318d0fb1baff2c9ff4809d7371 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b955b597a5e4f82480ac7bf4e2b727b33c7ec8318d0fb1baff2c9ff4809d7371->enter($__internal_b955b597a5e4f82480ac7bf4e2b727b33c7ec8318d0fb1baff2c9ff4809d7371_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        echo $this->env->getExtension('Knp\Menu\Twig\MenuExtension')->render(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["admin"]) || array_key_exists("admin", $context) ? $context["admin"] : (function () { throw new Twig_Error_Runtime('Variable "admin" does not exist.', 30, $this->getSourceContext()); })()), "sidemenu", array(0 => (isset($context["action"]) || array_key_exists("action", $context) ? $context["action"] : (function () { throw new Twig_Error_Runtime('Variable "action" does not exist.', 30, $this->getSourceContext()); })())), "method"), array("currentClass" => "active", "template" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["sonata_admin"]) || array_key_exists("sonata_admin", $context) ? $context["sonata_admin"] : (function () { throw new Twig_Error_Runtime('Variable "sonata_admin" does not exist.', 30, $this->getSourceContext()); })()), "adminPool", array()), "getTemplate", array(0 => "tab_menu_template"), "method")), "twig");
        
        $__internal_b955b597a5e4f82480ac7bf4e2b727b33c7ec8318d0fb1baff2c9ff4809d7371->leave($__internal_b955b597a5e4f82480ac7bf4e2b727b33c7ec8318d0fb1baff2c9ff4809d7371_prof);

        
        $__internal_6fa19cfa1579159e62b9ef8e2c5f974159ce2fb0026393201fb4ba8e4bf4be3f->leave($__internal_6fa19cfa1579159e62b9ef8e2c5f974159ce2fb0026393201fb4ba8e4bf4be3f_prof);

    }

    // line 34
    public function block_form($context, array $blocks = array())
    {
        $__internal_0a130423efc36ca7ca4df0a7cdac7b55389a6603c47d0fc12e9923c078943ad0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a130423efc36ca7ca4df0a7cdac7b55389a6603c47d0fc12e9923c078943ad0->enter($__internal_0a130423efc36ca7ca4df0a7cdac7b55389a6603c47d0fc12e9923c078943ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form"));

        $__internal_f5cdec5b1173738e8e2068abb9287c4aedf2d63dbac05d014edc4da497562d12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5cdec5b1173738e8e2068abb9287c4aedf2d63dbac05d014edc4da497562d12->enter($__internal_f5cdec5b1173738e8e2068abb9287c4aedf2d63dbac05d014edc4da497562d12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form"));

        // line 35
        echo "    ";
        $this->displayBlock("parentForm", $context, $blocks);
        echo "
";
        
        $__internal_f5cdec5b1173738e8e2068abb9287c4aedf2d63dbac05d014edc4da497562d12->leave($__internal_f5cdec5b1173738e8e2068abb9287c4aedf2d63dbac05d014edc4da497562d12_prof);

        
        $__internal_0a130423efc36ca7ca4df0a7cdac7b55389a6603c47d0fc12e9923c078943ad0->leave($__internal_0a130423efc36ca7ca4df0a7cdac7b55389a6603c47d0fc12e9923c078943ad0_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:base_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 35,  152 => 34,  134 => 30,  124 => 27,  115 => 26,  102 => 23,  93 => 22,  79 => 18,  73 => 16,  70 => 15,  61 => 14,  40 => 12,  12 => 32,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block title %}
    {% if admin.id(object) is not null %}
        {{ \"title_edit\"|trans({'%name%': admin.toString(object)|truncate(15) }, 'SonataAdminBundle') }}
    {% else %}
        {{ \"title_create\"|trans({}, 'SonataAdminBundle') }}
    {% endif %}
{% endblock %}

{% block navbar_title %}
    {{ block('title') }}
{% endblock %}

{%- block actions -%}
    {% include 'SonataAdminBundle:CRUD:action_buttons.html.twig' %}
{%- endblock -%}

{% block tab_menu %}{{ knp_menu_render(admin.sidemenu(action), {'currentClass' : 'active', 'template': sonata_admin.adminPool.getTemplate('tab_menu_template')}, 'twig') }}{% endblock %}

{% use 'SonataAdminBundle:CRUD:base_edit_form.html.twig' with form as parentForm %}

{% block form %}
    {{ block('parentForm') }}
{% endblock %}
", "SonataAdminBundle:CRUD:base_edit.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/base_edit.html.twig");
    }
}
