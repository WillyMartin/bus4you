<?php

/* SonataFormatterBundle:Form:formatter.html.twig */
class __TwigTemplate_bb668e9d1e3708d56b94079cb16eeb71fb37c7833a04903c9915dc5183a2d7dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'sonata_formatter_type_widget' => array($this, 'block_sonata_formatter_type_widget'),
            'sonata_simple_formatter_type_widget' => array($this, 'block_sonata_simple_formatter_type_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e1e03aeebad1fbf1668fe719c2510d6719e5d3512829c6d77730e6d0ab29057 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e1e03aeebad1fbf1668fe719c2510d6719e5d3512829c6d77730e6d0ab29057->enter($__internal_1e1e03aeebad1fbf1668fe719c2510d6719e5d3512829c6d77730e6d0ab29057_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataFormatterBundle:Form:formatter.html.twig"));

        $__internal_d0740bc78e25c2b140c7b4d4b0a6b56a9243b6056cd83e6f5f615afe168e2f27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0740bc78e25c2b140c7b4d4b0a6b56a9243b6056cd83e6f5f615afe168e2f27->enter($__internal_d0740bc78e25c2b140c7b4d4b0a6b56a9243b6056cd83e6f5f615afe168e2f27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataFormatterBundle:Form:formatter.html.twig"));

        // line 1
        $this->displayBlock('sonata_formatter_type_widget', $context, $blocks);
        // line 61
        echo "
";
        // line 62
        $this->displayBlock('sonata_simple_formatter_type_widget', $context, $blocks);
        
        $__internal_1e1e03aeebad1fbf1668fe719c2510d6719e5d3512829c6d77730e6d0ab29057->leave($__internal_1e1e03aeebad1fbf1668fe719c2510d6719e5d3512829c6d77730e6d0ab29057_prof);

        
        $__internal_d0740bc78e25c2b140c7b4d4b0a6b56a9243b6056cd83e6f5f615afe168e2f27->leave($__internal_d0740bc78e25c2b140c7b4d4b0a6b56a9243b6056cd83e6f5f615afe168e2f27_prof);

    }

    // line 1
    public function block_sonata_formatter_type_widget($context, array $blocks = array())
    {
        $__internal_31b8f93de2a19744e87f811ba9edf87bbc87490559fc73d86a5f308f1ec40a3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_31b8f93de2a19744e87f811ba9edf87bbc87490559fc73d86a5f308f1ec40a3b->enter($__internal_31b8f93de2a19744e87f811ba9edf87bbc87490559fc73d86a5f308f1ec40a3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_formatter_type_widget"));

        $__internal_4bfb6ed45d2cee226c221491a2a7054855c6954edda056de9b180fb53fa9ba94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bfb6ed45d2cee226c221491a2a7054855c6954edda056de9b180fb53fa9ba94->enter($__internal_4bfb6ed45d2cee226c221491a2a7054855c6954edda056de9b180fb53fa9ba94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_formatter_type_widget"));

        // line 2
        echo "
    <!-- widget: sonata_formatter_type_widget -->
    <div style=\"margin-bottom: 5px;\">
        ";
        // line 5
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 5, $this->getSourceContext()); })()), "children", array()), (isset($context["format_field"]) || array_key_exists("format_field", $context) ? $context["format_field"] : (function () { throw new Twig_Error_Runtime('Variable "format_field" does not exist.', 5, $this->getSourceContext()); })()), array(), "array"), 'widget');
        echo "
        ";
        // line 6
        if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["format_field_options"]) || array_key_exists("format_field_options", $context) ? $context["format_field_options"] : (function () { throw new Twig_Error_Runtime('Variable "format_field_options" does not exist.', 6, $this->getSourceContext()); })()), "choices", array())) > 1)) {
            // line 7
            echo "            <i>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("please_select_format_method", array(), "SonataFormatterBundle"), "html", null, true);
            echo "</i>
        ";
        }
        // line 9
        echo "    </div>

    ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), "children", array()), (isset($context["source_field"]) || array_key_exists("source_field", $context) ? $context["source_field"] : (function () { throw new Twig_Error_Runtime('Variable "source_field" does not exist.', 11, $this->getSourceContext()); })()), array(), "array"), 'widget');
        echo "
    <script>
        jQuery(document).ready(function() {

            // This code requires CKEDITOR and jQuery MarkItUp
            if (typeof CKEDITOR === 'undefined' || jQuery().markItUp == undefined) {
                return;
            }

            jQuery('#";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 20, $this->getSourceContext()); })()), "children", array()), (isset($context["format_field"]) || array_key_exists("format_field", $context) ? $context["format_field"] : (function () { throw new Twig_Error_Runtime('Variable "format_field" does not exist.', 20, $this->getSourceContext()); })()), array(), "array"), "vars", array()), "id", array()), "html", null, true);
        echo "').change(function(event) {
                var elms = jQuery('#";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 21, $this->getSourceContext()); })()), "children", array()), (isset($context["source_field"]) || array_key_exists("source_field", $context) ? $context["source_field"] : (function () { throw new Twig_Error_Runtime('Variable "source_field" does not exist.', 21, $this->getSourceContext()); })()), array(), "array"), "vars", array()), "id", array()), "html", null, true);
        echo "');
                elms.markItUpRemove();

                ";
        // line 24
        echo $this->env->getExtension('Ivory\CKEditorBundle\Twig\CKEditorExtension')->renderDestroy(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 24, $this->getSourceContext()); })()), "children", array()), (isset($context["source_field"]) || array_key_exists("source_field", $context) ? $context["source_field"] : (function () { throw new Twig_Error_Runtime('Variable "source_field" does not exist.', 24, $this->getSourceContext()); })()), array(), "array"), "vars", array()), "id", array()));
        echo "

                var val = jQuery(this).val();
                var appendClass = val;
                switch(val) {
                    case 'textile':
                        elms.markItUp(markitup_sonataTextileSettings);
                        break;
                    case 'markdown':
                        elms.markItUp(markitup_sonataMarkdownSettings);
                        break;
                    case 'bbcode':
                        elms.markItUp(markitup_sonataBBCodeSettings);
                        break;
                    case 'rawhtml':
                        elms.markItUp(markitup_sonataHtmlSettings);
                        appendClass = 'html';
                        break;
                    case 'richhtml':
                        ";
        // line 43
        $this->loadTemplate("SonataFormatterBundle:Form:ckeditor.html.twig", "SonataFormatterBundle:Form:formatter.html.twig", 43)->display(array_merge($context, array("ckeditor_field_id" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 43, $this->getSourceContext()); })()), "children", array()), (isset($context["source_field"]) || array_key_exists("source_field", $context) ? $context["source_field"] : (function () { throw new Twig_Error_Runtime('Variable "source_field" does not exist.', 43, $this->getSourceContext()); })()), array(), "array"), "vars", array()), "id", array()))));
        // line 44
        echo "                }

                var parent = elms.parents('div.markItUp');

                if (parent) {
                    for (name in ['textile', 'markdown', 'bbcode', 'rawhtml', 'richhtml', 'rawhtml']) {
                        parent.removeClass(name)
                    }

                    parent.addClass(appendClass);
                }
            });

            jQuery('#";
        // line 57
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 57, $this->getSourceContext()); })()), "children", array()), (isset($context["format_field"]) || array_key_exists("format_field", $context) ? $context["format_field"] : (function () { throw new Twig_Error_Runtime('Variable "format_field" does not exist.', 57, $this->getSourceContext()); })()), array(), "array"), "vars", array()), "id", array()), "html", null, true);
        echo "').trigger('change');
        });
    </script>
";
        
        $__internal_4bfb6ed45d2cee226c221491a2a7054855c6954edda056de9b180fb53fa9ba94->leave($__internal_4bfb6ed45d2cee226c221491a2a7054855c6954edda056de9b180fb53fa9ba94_prof);

        
        $__internal_31b8f93de2a19744e87f811ba9edf87bbc87490559fc73d86a5f308f1ec40a3b->leave($__internal_31b8f93de2a19744e87f811ba9edf87bbc87490559fc73d86a5f308f1ec40a3b_prof);

    }

    // line 62
    public function block_sonata_simple_formatter_type_widget($context, array $blocks = array())
    {
        $__internal_11d0e71fde4798a4c79921b9e6742150bb72ee2bd466df57a90cd5d135a3653d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11d0e71fde4798a4c79921b9e6742150bb72ee2bd466df57a90cd5d135a3653d->enter($__internal_11d0e71fde4798a4c79921b9e6742150bb72ee2bd466df57a90cd5d135a3653d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_simple_formatter_type_widget"));

        $__internal_9c27be76e7be705e66afaad7b800c131ac9b8862b8bdfc9a365f2154aa1d6c9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c27be76e7be705e66afaad7b800c131ac9b8862b8bdfc9a365f2154aa1d6c9a->enter($__internal_9c27be76e7be705e66afaad7b800c131ac9b8862b8bdfc9a365f2154aa1d6c9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_simple_formatter_type_widget"));

        // line 63
        echo "
    <!-- widget: sonata_simple_formatter_type_widget -->

    ";
        // line 66
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 66, $this->getSourceContext()); })()), 'widget');
        echo "

    <script>
        jQuery(document).ready(function() {
            // This code requires CKEDITOR and jQuery MarkItUp
            if (typeof CKEDITOR === 'undefined' || jQuery().markItUp == undefined) {
                return;
            }

            var elms = jQuery('#";
        // line 75
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 75, $this->getSourceContext()); })()), "vars", array()), "id", array()), "html", null, true);
        echo "');

            ";
        // line 77
        if (((isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 77, $this->getSourceContext()); })()) == "textile")) {
            // line 78
            echo "                elms.markItUp(markitup_sonataTextileSettings);
            ";
        } elseif ((        // line 79
(isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 79, $this->getSourceContext()); })()) == "markdown")) {
            // line 80
            echo "                elms.markItUp(markitup_sonataMarkdownSettings);
            ";
        } elseif ((        // line 81
(isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 81, $this->getSourceContext()); })()) == "bbcode")) {
            // line 82
            echo "                elms.markItUp(markitup_sonataBBCodeSettings);
            ";
        } elseif ((        // line 83
(isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 83, $this->getSourceContext()); })()) == "rawhtml")) {
            // line 84
            echo "                elms.markItUp(markitup_sonataHtmlSettings);
            ";
        } elseif ((        // line 85
(isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 85, $this->getSourceContext()); })()) == "richhtml")) {
            // line 86
            echo "                ";
            $this->loadTemplate("SonataFormatterBundle:Form:ckeditor.html.twig", "SonataFormatterBundle:Form:formatter.html.twig", 86)->display(array_merge($context, array("ckeditor_field_id" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 86, $this->getSourceContext()); })()), "vars", array()), "id", array()))));
            // line 87
            echo "            ";
        }
        // line 88
        echo "
            var parent = elms.parents('div.markItUp');

            if (parent) {
                parent.addClass('";
        // line 92
        echo twig_escape_filter($this->env, (isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 92, $this->getSourceContext()); })()), "html", null, true);
        echo "');
                ";
        // line 93
        if (((isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 93, $this->getSourceContext()); })()) == "rawhtml")) {
            // line 94
            echo "                    parent.addClass('html');
                ";
        }
        // line 96
        echo "            }

        });
    </script>
";
        
        $__internal_9c27be76e7be705e66afaad7b800c131ac9b8862b8bdfc9a365f2154aa1d6c9a->leave($__internal_9c27be76e7be705e66afaad7b800c131ac9b8862b8bdfc9a365f2154aa1d6c9a_prof);

        
        $__internal_11d0e71fde4798a4c79921b9e6742150bb72ee2bd466df57a90cd5d135a3653d->leave($__internal_11d0e71fde4798a4c79921b9e6742150bb72ee2bd466df57a90cd5d135a3653d_prof);

    }

    public function getTemplateName()
    {
        return "SonataFormatterBundle:Form:formatter.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  222 => 96,  218 => 94,  216 => 93,  212 => 92,  206 => 88,  203 => 87,  200 => 86,  198 => 85,  195 => 84,  193 => 83,  190 => 82,  188 => 81,  185 => 80,  183 => 79,  180 => 78,  178 => 77,  173 => 75,  161 => 66,  156 => 63,  147 => 62,  133 => 57,  118 => 44,  116 => 43,  94 => 24,  88 => 21,  84 => 20,  72 => 11,  68 => 9,  62 => 7,  60 => 6,  56 => 5,  51 => 2,  42 => 1,  32 => 62,  29 => 61,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block sonata_formatter_type_widget %}

    <!-- widget: sonata_formatter_type_widget -->
    <div style=\"margin-bottom: 5px;\">
        {{ form_widget(form.children[format_field]) }}
        {% if format_field_options.choices|length > 1 %}
            <i>{{ \"please_select_format_method\"|trans({}, \"SonataFormatterBundle\") }}</i>
        {% endif %}
    </div>

    {{ form_widget(form.children[source_field]) }}
    <script>
        jQuery(document).ready(function() {

            // This code requires CKEDITOR and jQuery MarkItUp
            if (typeof CKEDITOR === 'undefined' || jQuery().markItUp == undefined) {
                return;
            }

            jQuery('#{{ form.children[format_field].vars.id }}').change(function(event) {
                var elms = jQuery('#{{ form.children[source_field].vars.id }}');
                elms.markItUpRemove();

                {{ ckeditor_destroy(form.children[source_field].vars.id) }}

                var val = jQuery(this).val();
                var appendClass = val;
                switch(val) {
                    case 'textile':
                        elms.markItUp(markitup_sonataTextileSettings);
                        break;
                    case 'markdown':
                        elms.markItUp(markitup_sonataMarkdownSettings);
                        break;
                    case 'bbcode':
                        elms.markItUp(markitup_sonataBBCodeSettings);
                        break;
                    case 'rawhtml':
                        elms.markItUp(markitup_sonataHtmlSettings);
                        appendClass = 'html';
                        break;
                    case 'richhtml':
                        {% include 'SonataFormatterBundle:Form:ckeditor.html.twig' with {'ckeditor_field_id': form.children[source_field].vars.id} %}
                }

                var parent = elms.parents('div.markItUp');

                if (parent) {
                    for (name in ['textile', 'markdown', 'bbcode', 'rawhtml', 'richhtml', 'rawhtml']) {
                        parent.removeClass(name)
                    }

                    parent.addClass(appendClass);
                }
            });

            jQuery('#{{ form.children[format_field].vars.id }}').trigger('change');
        });
    </script>
{% endblock sonata_formatter_type_widget %}

{% block sonata_simple_formatter_type_widget %}

    <!-- widget: sonata_simple_formatter_type_widget -->

    {{ form_widget(form) }}

    <script>
        jQuery(document).ready(function() {
            // This code requires CKEDITOR and jQuery MarkItUp
            if (typeof CKEDITOR === 'undefined' || jQuery().markItUp == undefined) {
                return;
            }

            var elms = jQuery('#{{ form.vars.id }}');

            {% if format == 'textile' %}
                elms.markItUp(markitup_sonataTextileSettings);
            {% elseif format == 'markdown' %}
                elms.markItUp(markitup_sonataMarkdownSettings);
            {% elseif format == 'bbcode' %}
                elms.markItUp(markitup_sonataBBCodeSettings);
            {% elseif format == 'rawhtml' %}
                elms.markItUp(markitup_sonataHtmlSettings);
            {% elseif format == 'richhtml' %}
                {% include 'SonataFormatterBundle:Form:ckeditor.html.twig' with {'ckeditor_field_id': form.vars.id} %}
            {% endif %}

            var parent = elms.parents('div.markItUp');

            if (parent) {
                parent.addClass('{{ format }}');
                {% if format == 'rawhtml' %}
                    parent.addClass('html');
                {% endif %}
            }

        });
    </script>
{% endblock sonata_simple_formatter_type_widget %}
", "SonataFormatterBundle:Form:formatter.html.twig", "/var/www/bus4you/vendor/sonata-project/formatter-bundle/Resources/views/Form/formatter.html.twig");
    }
}
