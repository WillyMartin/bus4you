<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_b695983ca19d9e19827c3459aecd85a2207a8238e683f56ec513f3f831539047 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_056d597d1fdafde36763b1fc1b5c1d15696a847ec89f39bcf8a2a2972bfeed6a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_056d597d1fdafde36763b1fc1b5c1d15696a847ec89f39bcf8a2a2972bfeed6a->enter($__internal_056d597d1fdafde36763b1fc1b5c1d15696a847ec89f39bcf8a2a2972bfeed6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_07e8f7519b116ea9ff8f6f8bac4b992ac6e720d2b1d7fb135c1f8916c2fbea62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07e8f7519b116ea9ff8f6f8bac4b992ac6e720d2b1d7fb135c1f8916c2fbea62->enter($__internal_07e8f7519b116ea9ff8f6f8bac4b992ac6e720d2b1d7fb135c1f8916c2fbea62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_056d597d1fdafde36763b1fc1b5c1d15696a847ec89f39bcf8a2a2972bfeed6a->leave($__internal_056d597d1fdafde36763b1fc1b5c1d15696a847ec89f39bcf8a2a2972bfeed6a_prof);

        
        $__internal_07e8f7519b116ea9ff8f6f8bac4b992ac6e720d2b1d7fb135c1f8916c2fbea62->leave($__internal_07e8f7519b116ea9ff8f6f8bac4b992ac6e720d2b1d7fb135c1f8916c2fbea62_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square.svg");
    }
}
