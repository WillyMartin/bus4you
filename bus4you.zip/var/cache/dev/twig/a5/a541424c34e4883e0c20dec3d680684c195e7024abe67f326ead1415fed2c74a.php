<?php

/* SonataAdminBundle:CRUD:edit.html.twig */
class __TwigTemplate_6210164336a5ddbf10248215d0d1b77eeafa72f61d24ac42dfcd9efa7d816a8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataAdminBundle:CRUD:base_edit.html.twig", "SonataAdminBundle:CRUD:edit.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataAdminBundle:CRUD:base_edit.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acdf34120c722898d6c7f755b2a48c5768f5ddfc22f1c054be550cab9d3512c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_acdf34120c722898d6c7f755b2a48c5768f5ddfc22f1c054be550cab9d3512c3->enter($__internal_acdf34120c722898d6c7f755b2a48c5768f5ddfc22f1c054be550cab9d3512c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit.html.twig"));

        $__internal_b2f615d0d86b65cd1b39dbc033b0dcfb45f9dd1891709da03d48e7eb956f5efb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2f615d0d86b65cd1b39dbc033b0dcfb45f9dd1891709da03d48e7eb956f5efb->enter($__internal_b2f615d0d86b65cd1b39dbc033b0dcfb45f9dd1891709da03d48e7eb956f5efb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_acdf34120c722898d6c7f755b2a48c5768f5ddfc22f1c054be550cab9d3512c3->leave($__internal_acdf34120c722898d6c7f755b2a48c5768f5ddfc22f1c054be550cab9d3512c3_prof);

        
        $__internal_b2f615d0d86b65cd1b39dbc033b0dcfb45f9dd1891709da03d48e7eb956f5efb->leave($__internal_b2f615d0d86b65cd1b39dbc033b0dcfb45f9dd1891709da03d48e7eb956f5efb_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends 'SonataAdminBundle:CRUD:base_edit.html.twig' %}
", "SonataAdminBundle:CRUD:edit.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/CRUD/edit.html.twig");
    }
}
