<?php

/* SonataAdminBundle:Pager:results.html.twig */
class __TwigTemplate_341a3bf44c65d9430369a477fd36af6ca7ed7ffe014d06ca9228f6dfd4303411 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataAdminBundle:Pager:base_results.html.twig", "SonataAdminBundle:Pager:results.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataAdminBundle:Pager:base_results.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fed272da4505ad2b28d54a40bb4f527e491c5d3a87b1789648f9e2e6c831c64c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fed272da4505ad2b28d54a40bb4f527e491c5d3a87b1789648f9e2e6c831c64c->enter($__internal_fed272da4505ad2b28d54a40bb4f527e491c5d3a87b1789648f9e2e6c831c64c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:results.html.twig"));

        $__internal_eef4580e4c52400a45c5ff46e72a414f10bcb3ac1eca5a13ca06016d8837d99c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eef4580e4c52400a45c5ff46e72a414f10bcb3ac1eca5a13ca06016d8837d99c->enter($__internal_eef4580e4c52400a45c5ff46e72a414f10bcb3ac1eca5a13ca06016d8837d99c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:results.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fed272da4505ad2b28d54a40bb4f527e491c5d3a87b1789648f9e2e6c831c64c->leave($__internal_fed272da4505ad2b28d54a40bb4f527e491c5d3a87b1789648f9e2e6c831c64c_prof);

        
        $__internal_eef4580e4c52400a45c5ff46e72a414f10bcb3ac1eca5a13ca06016d8837d99c->leave($__internal_eef4580e4c52400a45c5ff46e72a414f10bcb3ac1eca5a13ca06016d8837d99c_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Pager:results.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends 'SonataAdminBundle:Pager:base_results.html.twig' %}
", "SonataAdminBundle:Pager:results.html.twig", "/var/www/bus4you/vendor/sonata-project/admin-bundle/Resources/views/Pager/results.html.twig");
    }
}
