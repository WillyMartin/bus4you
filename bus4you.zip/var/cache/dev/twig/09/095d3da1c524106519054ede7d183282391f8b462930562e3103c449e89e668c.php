<?php

/* @Security/Collector/icon.svg */
class __TwigTemplate_6518e7d678e3c343eaefd28ffe6408760910edce98bc50d0a0a57d9e600c5685 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8afaa5a98ddd26790bb373af56a53db09708e4e2650b7d3a686e5055ca0cb54d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8afaa5a98ddd26790bb373af56a53db09708e4e2650b7d3a686e5055ca0cb54d->enter($__internal_8afaa5a98ddd26790bb373af56a53db09708e4e2650b7d3a686e5055ca0cb54d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        $__internal_d94bc9f17e0eaf12337556e2b6b55b201367d2beeb33dcc7b816a1302fec6fe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d94bc9f17e0eaf12337556e2b6b55b201367d2beeb33dcc7b816a1302fec6fe7->enter($__internal_d94bc9f17e0eaf12337556e2b6b55b201367d2beeb33dcc7b816a1302fec6fe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
";
        
        $__internal_8afaa5a98ddd26790bb373af56a53db09708e4e2650b7d3a686e5055ca0cb54d->leave($__internal_8afaa5a98ddd26790bb373af56a53db09708e4e2650b7d3a686e5055ca0cb54d_prof);

        
        $__internal_d94bc9f17e0eaf12337556e2b6b55b201367d2beeb33dcc7b816a1302fec6fe7->leave($__internal_d94bc9f17e0eaf12337556e2b6b55b201367d2beeb33dcc7b816a1302fec6fe7_prof);

    }

    public function getTemplateName()
    {
        return "@Security/Collector/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
", "@Security/Collector/icon.svg", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle/Resources/views/Collector/icon.svg");
    }
}
