<?php

/* @WebProfiler/Profiler/header.html.twig */
class __TwigTemplate_4fa8fc21feea42d4931c0bb68c2be37e87a10f87d5d515120fd5f684a775c7a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_478e03017c809249cae8e51bd4044213971e00bcaa7010db97d38529b07bf142 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_478e03017c809249cae8e51bd4044213971e00bcaa7010db97d38529b07bf142->enter($__internal_478e03017c809249cae8e51bd4044213971e00bcaa7010db97d38529b07bf142_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        $__internal_9c46c079730fa2eb703bdff4847d50108eba34fd9baa75218bc1b165f59b2039 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c46c079730fa2eb703bdff4847d50108eba34fd9baa75218bc1b165f59b2039->enter($__internal_9c46c079730fa2eb703bdff4847d50108eba34fd9baa75218bc1b165f59b2039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_478e03017c809249cae8e51bd4044213971e00bcaa7010db97d38529b07bf142->leave($__internal_478e03017c809249cae8e51bd4044213971e00bcaa7010db97d38529b07bf142_prof);

        
        $__internal_9c46c079730fa2eb703bdff4847d50108eba34fd9baa75218bc1b165f59b2039->leave($__internal_9c46c079730fa2eb703bdff4847d50108eba34fd9baa75218bc1b165f59b2039_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "@WebProfiler/Profiler/header.html.twig", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/header.html.twig");
    }
}
