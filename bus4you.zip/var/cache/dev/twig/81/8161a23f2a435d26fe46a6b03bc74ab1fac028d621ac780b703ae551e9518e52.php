<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_34b6e74f5a1032002e44cb7e44adb9be0450b140bd55c36b42653553d3d3831b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ac5ca34201db82c6cd4b4fe75212751f9a38f0aeb8a24eb51a208eaa273738f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ac5ca34201db82c6cd4b4fe75212751f9a38f0aeb8a24eb51a208eaa273738f->enter($__internal_5ac5ca34201db82c6cd4b4fe75212751f9a38f0aeb8a24eb51a208eaa273738f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_19d9206dbfb54f973d757101e6064c5a52125f54a1739df1bced9666c26a177e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19d9206dbfb54f973d757101e6064c5a52125f54a1739df1bced9666c26a177e->enter($__internal_19d9206dbfb54f973d757101e6064c5a52125f54a1739df1bced9666c26a177e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5ac5ca34201db82c6cd4b4fe75212751f9a38f0aeb8a24eb51a208eaa273738f->leave($__internal_5ac5ca34201db82c6cd4b4fe75212751f9a38f0aeb8a24eb51a208eaa273738f_prof);

        
        $__internal_19d9206dbfb54f973d757101e6064c5a52125f54a1739df1bced9666c26a177e->leave($__internal_19d9206dbfb54f973d757101e6064c5a52125f54a1739df1bced9666c26a177e_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_8b121c2593a6b4dce2b5522bac12d50468ff3ffbaa6bebeed48da307d30b8c49 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b121c2593a6b4dce2b5522bac12d50468ff3ffbaa6bebeed48da307d30b8c49->enter($__internal_8b121c2593a6b4dce2b5522bac12d50468ff3ffbaa6bebeed48da307d30b8c49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_2730e3eede301142f30e66e8865386ae9b83f377f556623f794059901a4b1826 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2730e3eede301142f30e66e8865386ae9b83f377f556623f794059901a4b1826->enter($__internal_2730e3eede301142f30e66e8865386ae9b83f377f556623f794059901a4b1826_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_2730e3eede301142f30e66e8865386ae9b83f377f556623f794059901a4b1826->leave($__internal_2730e3eede301142f30e66e8865386ae9b83f377f556623f794059901a4b1826_prof);

        
        $__internal_8b121c2593a6b4dce2b5522bac12d50468ff3ffbaa6bebeed48da307d30b8c49->leave($__internal_8b121c2593a6b4dce2b5522bac12d50468ff3ffbaa6bebeed48da307d30b8c49_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_36c3a574dbd5eb4134ba5923ed64cdb597b5364e12257f458cac6c2e0e2329d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36c3a574dbd5eb4134ba5923ed64cdb597b5364e12257f458cac6c2e0e2329d3->enter($__internal_36c3a574dbd5eb4134ba5923ed64cdb597b5364e12257f458cac6c2e0e2329d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e4586991b9717d425d8169253b32953adc7df56dd7b858924db969de7d69ac1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4586991b9717d425d8169253b32953adc7df56dd7b858924db969de7d69ac1d->enter($__internal_e4586991b9717d425d8169253b32953adc7df56dd7b858924db969de7d69ac1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e4586991b9717d425d8169253b32953adc7df56dd7b858924db969de7d69ac1d->leave($__internal_e4586991b9717d425d8169253b32953adc7df56dd7b858924db969de7d69ac1d_prof);

        
        $__internal_36c3a574dbd5eb4134ba5923ed64cdb597b5364e12257f458cac6c2e0e2329d3->leave($__internal_36c3a574dbd5eb4134ba5923ed64cdb597b5364e12257f458cac6c2e0e2329d3_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_abe56200d3559bdb8c591274c97c096671da749de77985248f54f7abe20939f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_abe56200d3559bdb8c591274c97c096671da749de77985248f54f7abe20939f8->enter($__internal_abe56200d3559bdb8c591274c97c096671da749de77985248f54f7abe20939f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6e8086706aab49f0fe0392b204444acbbf560bf87656fe8e10f028f6c544838f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e8086706aab49f0fe0392b204444acbbf560bf87656fe8e10f028f6c544838f->enter($__internal_6e8086706aab49f0fe0392b204444acbbf560bf87656fe8e10f028f6c544838f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_6e8086706aab49f0fe0392b204444acbbf560bf87656fe8e10f028f6c544838f->leave($__internal_6e8086706aab49f0fe0392b204444acbbf560bf87656fe8e10f028f6c544838f_prof);

        
        $__internal_abe56200d3559bdb8c591274c97c096671da749de77985248f54f7abe20939f8->leave($__internal_abe56200d3559bdb8c591274c97c096671da749de77985248f54f7abe20939f8_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/var/www/bus4you/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
