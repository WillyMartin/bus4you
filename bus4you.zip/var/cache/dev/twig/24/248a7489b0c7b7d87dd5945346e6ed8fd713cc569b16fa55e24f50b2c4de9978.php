<?php

/* FOSUserBundle:Security:login_content.html.twig */
class __TwigTemplate_5170e6985344db325b8aeadf41319e05fab313740bf1127520624462ef6ae6d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3de8788a1c5bd1726081d0516f0b2f0e61575a0776024bc83dc6065229b02374 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3de8788a1c5bd1726081d0516f0b2f0e61575a0776024bc83dc6065229b02374->enter($__internal_3de8788a1c5bd1726081d0516f0b2f0e61575a0776024bc83dc6065229b02374_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        $__internal_059d70ce8d462d4d1bdf06d02a17ac528b9137048757e92d81cdd969b3e8a5a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_059d70ce8d462d4d1bdf06d02a17ac528b9137048757e92d81cdd969b3e8a5a3->enter($__internal_059d70ce8d462d4d1bdf06d02a17ac528b9137048757e92d81cdd969b3e8a5a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login_content.html.twig"));

        // line 2
        echo "
";
        // line 3
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 3, $this->getSourceContext()); })())) {
            // line 4
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 4, $this->getSourceContext()); })()), "messageKey", array()), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 4, $this->getSourceContext()); })()), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 6
        echo "

                                    <form action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" class=\"enter_cabinet\" method=\"post\">
                                        ";
        // line 9
        if ((isset($context["csrf_token"]) || array_key_exists("csrf_token", $context) ? $context["csrf_token"] : (function () { throw new Twig_Error_Runtime('Variable "csrf_token" does not exist.', 9, $this->getSourceContext()); })())) {
            // line 10
            echo "                                            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["csrf_token"]) || array_key_exists("csrf_token", $context) ? $context["csrf_token"] : (function () { throw new Twig_Error_Runtime('Variable "csrf_token" does not exist.', 10, $this->getSourceContext()); })()), "html", null, true);
            echo "\" />
                                        ";
        }
        // line 12
        echo "
                                        <label for=\"username\">";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new Twig_Error_Runtime('Variable "last_username" does not exist.', 14, $this->getSourceContext()); })()), "html", null, true);
        echo "\" placeholder=\"example@mail.com\" required=\"required\" />

                                        <label for=\"password\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                                        <input type=\"password\" id=\"password\" name=\"_password\" placeholder=\"******\" required=\"required\" />

                                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
                                        <label class=\"remember_me\" for=\"remember_me\">";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>

                                        <input type=\"submit\" class=\"form_btn\" id=\"_submit\" name=\"_submit\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
                                    </form>
       ";
        
        $__internal_3de8788a1c5bd1726081d0516f0b2f0e61575a0776024bc83dc6065229b02374->leave($__internal_3de8788a1c5bd1726081d0516f0b2f0e61575a0776024bc83dc6065229b02374_prof);

        
        $__internal_059d70ce8d462d4d1bdf06d02a17ac528b9137048757e92d81cdd969b3e8a5a3->leave($__internal_059d70ce8d462d4d1bdf06d02a17ac528b9137048757e92d81cdd969b3e8a5a3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 22,  71 => 20,  64 => 16,  59 => 14,  55 => 13,  52 => 12,  46 => 10,  44 => 9,  40 => 8,  36 => 6,  30 => 4,  28 => 3,  25 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

{% if error %}
    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
{% endif %}


                                    <form action=\"{{ path(\"fos_user_security_check\") }}\" class=\"enter_cabinet\" method=\"post\">
                                        {% if csrf_token %}
                                            <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
                                        {% endif %}

                                        <label for=\"username\">{{ 'security.login.username'|trans }}</label>
                                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" placeholder=\"example@mail.com\" required=\"required\" />

                                        <label for=\"password\">{{ 'security.login.password'|trans }}</label>
                                        <input type=\"password\" id=\"password\" name=\"_password\" placeholder=\"******\" required=\"required\" />

                                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
                                        <label class=\"remember_me\" for=\"remember_me\">{{ 'security.login.remember_me'|trans }}</label>

                                        <input type=\"submit\" class=\"form_btn\" id=\"_submit\" name=\"_submit\" value=\"{{ 'security.login.submit'|trans }}\" />
                                    </form>
       ", "FOSUserBundle:Security:login_content.html.twig", "/var/www/bus4you/app/Resources/FOSUserBundle/views/Security/login_content.html.twig");
    }
}
