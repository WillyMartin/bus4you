<?php

/* SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig */
class __TwigTemplate_565e22f7c5603f504a3568d2e753ae16b8137f2a0c7d70457b60c5c945cacfc9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("SonataAdminBundle:Form:filter_admin_fields.html.twig", "SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "SonataAdminBundle:Form:filter_admin_fields.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84e2ce3cec1a03e9b97d944ba7ce6000d2d9538d87aec28a8ce818c4306fdb21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84e2ce3cec1a03e9b97d944ba7ce6000d2d9538d87aec28a8ce818c4306fdb21->enter($__internal_84e2ce3cec1a03e9b97d944ba7ce6000d2d9538d87aec28a8ce818c4306fdb21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig"));

        $__internal_98c5873d50c6a44f544ce38caa0730b0a0b8174559bda48d1e028de1e4014433 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98c5873d50c6a44f544ce38caa0730b0a0b8174559bda48d1e028de1e4014433->enter($__internal_98c5873d50c6a44f544ce38caa0730b0a0b8174559bda48d1e028de1e4014433_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84e2ce3cec1a03e9b97d944ba7ce6000d2d9538d87aec28a8ce818c4306fdb21->leave($__internal_84e2ce3cec1a03e9b97d944ba7ce6000d2d9538d87aec28a8ce818c4306fdb21_prof);

        
        $__internal_98c5873d50c6a44f544ce38caa0730b0a0b8174559bda48d1e028de1e4014433->leave($__internal_98c5873d50c6a44f544ce38caa0730b0a0b8174559bda48d1e028de1e4014433_prof);

    }

    public function getTemplateName()
    {
        return "SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends 'SonataAdminBundle:Form:filter_admin_fields.html.twig' %}
", "SonataDoctrineORMAdminBundle:Form:filter_admin_fields.html.twig", "/var/www/bus4you/vendor/sonata-project/doctrine-orm-admin-bundle/Resources/views/Form/filter_admin_fields.html.twig");
    }
}
